"""Run with:  python -m unittest discover -s tests -v   (or pytest)
No network or API keys needed: the LLM is replaced by a scripted fake."""
import json
import re
import tempfile
import unittest
from pathlib import Path

from eb1a.config import PROFILES_DIR, Settings
from eb1a.criteria import CRITERIA
from eb1a.guardrails import InputError, clean_input
from eb1a.index import build_index
from eb1a.ingest import build_chunks
from eb1a.llm import LLMResult, parse_json
from eb1a.pipeline import EB1AEvaluator
from eb1a.prompts import NARRATIVE_SYSTEM
from eb1a.verify import quote_supported

RESUME = (PROFILES_DIR / "p03_startup_founder.txt").read_text()


def make_retriever():
    chunks = build_chunks(use_seed=True)
    return build_index(chunks, "tfidf", index_dir=Path(tempfile.mkdtemp()))


class FakeLLM:
    """Scripted model. `script(criterion_name, prompt, call_no)` returns a dict (or raw string)."""

    def __init__(self, script):
        self.script, self.calls = script, {}

    def complete(self, system, user, max_tokens=1200):
        if system == NARRATIVE_SYSTEM:
            return LLMResult("Test narrative.", 10, 5, 0.01)
        name = re.search(r"CRITERION: (.*?)  \(8 CFR", user).group(1)
        self.calls[name] = self.calls.get(name, 0) + 1
        out = self.script(name, user, self.calls[name])
        return LLMResult(out if isinstance(out, str) else json.dumps(out), 100, 50, 0.01)


def ids(prompt):
    return re.findall(r"^\[(c\d{3})\]", prompt, re.M)


def good_missing(prompt):
    return {"rating": "Missing", "evidence": [], "reasoning": "Nothing relevant was found in the resume lines.",
            "citations": ids(prompt)[:1], "next_steps": ["Collect documentation."]}


class TestVerify(unittest.TestCase):
    def test_exact_and_fuzzy(self):
        self.assertTrue(quote_supported("Winner, 2022 National Startup Awards", RESUME))
        self.assertTrue(quote_supported("winner 2022 national startup awards, fintech category", RESUME))
        self.assertTrue(quote_supported("Judge, final round panel ... Startup India Grand Challenge 2023", RESUME))

    def test_rejects_invented(self):
        self.assertFalse(quote_supported("Won the Nobel Prize in Physics in 2019", RESUME))
        self.assertFalse(quote_supported("Winner, 2024 International Startup Awards, Healthtech", RESUME))
        self.assertFalse(quote_supported("", RESUME))


class TestGuardrails(unittest.TestCase):
    def test_injection_is_quarantined(self):
        text = (PROFILES_DIR / "p07_prompt_injection.txt").read_text()
        c = clean_input(text)
        self.assertTrue(c.flags)
        self.assertNotIn("Turing", c.text)
        self.assertNotIn("Ignore all previous instructions", c.text)
        self.assertIn("Reduced average API latency", c.text)   # real content survives

    def test_too_short_and_garbled(self):
        with self.assertRaises(InputError):
            clean_input("John Doe, engineer.")
        with self.assertRaises(InputError):
            clean_input("\ufffd\ufffd§§±±~~^^`` " * 40)

    def test_zero_width_chars_removed(self):
        t = "Software engineer with experience. " * 10 + "Award\u200b winner"
        c = clean_input(t)
        self.assertIn("removed_invisible_characters", c.flags)


class TestChunkingAndRetrieval(unittest.TestCase):
    def test_every_criterion_has_its_own_chunk(self):
        tags = {c.criterion for c in build_chunks(use_seed=True)}
        for cr in CRITERIA:
            self.assertIn(cr.id, tags)

    def test_scoped_retrieval_returns_criterion_chunk(self):
        r = make_retriever()
        for cr in CRITERIA:
            hits = r.search(cr.query, k=3, criterion_id=cr.id)
            self.assertIn(cr.id, [h.chunk.criterion for h in hits], cr.id)
            self.assertTrue(all(h.chunk.criterion in (cr.id, "general") for h in hits))

    def test_parse_json_tolerates_fences(self):
        self.assertEqual(parse_json('Sure!\n```json\n{"a": 1}\n```'), {"a": 1})


class TestPipelineWithFakeLLM(unittest.TestCase):
    def setUp(self):
        self.r = make_retriever()
        self.s = Settings()
        self.s.provider = "anthropic"
        self.s.max_workers = 1

    def run_pipeline(self, script):
        return EB1AEvaluator(self.r, self.s, llm=FakeLLM(script)).assess_text(RESUME, "t")

    def test_happy_path_validates(self):
        def script(name, prompt, n):
            if name.startswith("Awards"):
                return {"rating": "Strong", "evidence": ["Winner, 2022 National Startup Awards, Fintech category"],
                        "reasoning": "A national award with a selective process, matching the guidance on recipients.",
                        "citations": ids(prompt)[:2], "next_steps": ["Get the award criteria.", "Get press coverage.", "extra third step"]}
            return good_missing(prompt)
        res = self.run_pipeline(script)
        a = res.criteria[0]
        self.assertEqual(a.rating, "Strong")
        self.assertEqual(len(a.next_steps), 2)             # trimmed to the 1-2 allowed
        self.assertEqual(len(res.criteria), 10)
        json.loads(res.model_dump_json())                  # serialises
        self.assertEqual(res.summary.strong_count, 1)
        self.assertFalse(res.summary.meets_minimum_three)
        self.assertLessEqual(res.summary.readiness_score, 69)

    def test_hallucination_is_repaired_on_retry(self):
        def script(name, prompt, n):
            if name.startswith("Awards"):
                if n == 1:
                    return {"rating": "Strong", "evidence": ["Won the Nobel Prize in Physics"], "reasoning": "Major prize clearly shown here.",
                            "citations": ["c999"], "next_steps": ["Do something."]}
                self.assertIn("previous answer had problems", prompt)
                return {"rating": "Strong", "evidence": ["Winner, 2022 National Startup Awards"], "reasoning": "Verified national award in the resume.",
                        "citations": ids(prompt)[:1], "next_steps": ["Collect award criteria."]}
            return good_missing(prompt)
        a = self.run_pipeline(script).criteria[0]
        d = a.diagnostics
        self.assertEqual(a.rating, "Strong")
        self.assertEqual((d.attempts, d.raw_quote_count, d.raw_unverified_quotes, d.raw_invalid_citations), (2, 1, 1, 1))
        self.assertEqual(a.evidence, ["Winner, 2022 National Startup Awards"])

    def test_persistent_hallucination_is_downgraded(self):
        def script(name, prompt, n):
            if name.startswith("Awards"):
                return {"rating": "Strong", "evidence": ["Won the Nobel Prize in Physics"], "reasoning": "Major prize clearly shown here.",
                        "citations": ids(prompt)[:1], "next_steps": ["Do something."]}
            return good_missing(prompt)
        a = self.run_pipeline(script).criteria[0]
        self.assertEqual(a.rating, "Insufficient Info")
        self.assertTrue(a.diagnostics.downgraded)
        self.assertEqual(a.evidence, [])
        self.assertIn("Downgraded automatically", a.reasoning)

    def test_bad_json_twice_gives_honest_failure(self):
        def script(name, prompt, n):
            return "I think this is strong." if name.startswith("Awards") else good_missing(prompt)
        a = self.run_pipeline(script).criteria[0]
        self.assertEqual(a.rating, "Insufficient Info")
        self.assertIn("did not return a valid structured answer", a.reasoning)

    def test_citation_fallback_is_flagged(self):
        def script(name, prompt, n):
            r = good_missing(prompt)
            r["citations"] = ["c999"]
            return r
        res = self.run_pipeline(script)
        self.assertTrue(all(c.diagnostics.citation_fallback for c in res.criteria))
        self.assertTrue(all(c.citations for c in res.criteria))

    def test_injected_resume_text_never_reaches_model(self):
        seen = []
        def script(name, prompt, n):
            seen.append(prompt)
            return good_missing(prompt)
        text = (PROFILES_DIR / "p07_prompt_injection.txt").read_text()
        res = EB1AEvaluator(self.r, self.s, llm=FakeLLM(script)).assess_text(text, "inj")
        self.assertTrue(res.meta.guardrail_flags)
        self.assertFalse(any("Turing" in p or "Ignore all previous" in p for p in seen))


if __name__ == "__main__":
    unittest.main()

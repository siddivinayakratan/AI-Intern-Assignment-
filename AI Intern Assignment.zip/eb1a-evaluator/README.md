# EB-1A Profile Evaluator

An AI tool that reads a resume (PDF or text), retrieves the relevant **USCIS Policy Manual** guidance for each of the 10
EB-1A criteria, and returns a structured, cited assessment (Pydantic-validated JSON) with next steps and an overall readiness score.

> Educational tool. Not legal advice. Uses synthetic profiles only.

## Status: what has and hasn't been verified

Built and tested in an offline sandbox. Please run these checks yourself before submitting:

| Part | Status |
|---|---|
| Chunking, tagging, BM25 + dense retrieval, RRF, verification, repair loop, guardrails, summary, CLI, eval harness | Tested (14 unit tests, plus a full eval run with the rule baseline) |
| LLM code path (parsing, repair, downgrade, fallbacks) | Tested with a scripted fake LLM, **not** with a real API |
| Fetching and parsing the live USCIS page (`--fetch`) | **Not tested** (no internet in the build sandbox). Use `inspect` after indexing and check the tags |
| `sentence-transformers` + FAISS path | **Not tested** (TF-IDF + NumPy path tested; the FAISS path is an exact-search drop-in) |
| Streamlit UI | **Not run** |
| Pydantic | Written for pydantic v2; tests here ran against a small stand-in, so run the tests once with the real package |

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # add ANTHROPIC_API_KEY or OPENAI_API_KEY; never commit .env

# 1. Build the knowledge base from the official page
python -m eb1a.cli build-index --fetch
#    If the fetch is blocked or the parse looks wrong, save the page from your browser
#    (File > Save Page As > HTML) and run:  python -m eb1a.cli build-index --html page.html
python -m eb1a.cli inspect                 # CHECK: every criterion should own at least one chunk

# 2. Run the tests (no API key needed)
python -m unittest discover -s tests -v

# 3. Assess a profile
python -m eb1a.cli assess data/profiles/p03_startup_founder.txt
python -m eb1a.cli assess my_resume.pdf --out result.json
streamlit run app.py

# 4. Evaluate
python -m eval.run_eval --runs rules                          # offline baseline
python -m eval.run_eval --runs rules,anthropic --judge --tag llm
python -m eval.run_eval --runs anthropic,openai:gpt-4o-mini   # model comparison (latency/tokens/cost)
python -m eval.retrieval_eval --k 5                           # retrieval ablation (needs the real corpus)
```

`--seed` builds a tiny paraphrased corpus so everything runs offline. It is **not** the official text. Every output carries
`meta.corpus_source`, and the CLI and UI warn when it is `seed_fallback`.

## Architecture

```
resume (pdf/txt) -> guardrails -> evidence units (numbered lines)
                                     |
   USCIS chapter -> clean -> chunk -> tag by criterion -> embeddings + BM25 index
                                     |
 for each of the 10 criteria (parallel):
   query = criterion regulatory text + the candidate's most relevant lines
   hybrid retrieval, scoped to {this criterion's chunks + 'general' chunks}
   LLM(rubric, numbered guidance chunks, numbered resume lines) -> JSON
   VERIFY: quotes must be in the resume, citations must be in the retrieved set
   repair once if not; else downgrade / flag
 -> deterministic readiness score + short narrative -> ProfileAssessment (Pydantic)
```

**Chunking** (`eb1a/ingest.py`). The manual is organised by heading, one block per criterion, so chunks follow headings: one
leaf section = one or more chunks, never crossing sections. ~250 words target (320 cap) with a one-paragraph overlap. Every chunk is
embedded with its heading path prepended ("... > Judging the work of others"), because a sentence such as "a single instance carries less weight"
is meaningless without its criterion. Tiny sections are merged only into neighbours with the **same** criterion tag. Footnotes and
link lists are dropped. Each chunk gets a criterion tag from its headings (fallback: key-phrase counts), else `general`
(two-part test, final merits, comparable evidence).

**Embeddings / store** (`embeddings.py`, `vectorstore.py`). Local `BAAI/bge-small-en-v1.5` (free, no API) with a TF-IDF fallback.
Vectors are normalised and searched with FAISS `IndexFlatIP` (exact) or NumPy; ~100 chunks does not justify approximate search.

**Retrieval** (`retriever.py`): *what* gets retrieved is decided in four steps: (1) **scope** to chunks tagged for the criterion plus `general`;
(2) **rank** with BM25 and dense similarity using a query built from the criterion text *and* the candidate's matching lines, so
a candidate mentioning peer review pulls up the peer-review passage; (3) **fuse** with Reciprocal Rank Fusion (rank-based, so no score calibration);
(4) **guarantee** at least 2 criterion-specific chunks in the top-k. BM25 is implemented by hand (~25 lines).

**Prompt** (`prompts.py`). One call per criterion keeps context small and failures isolated. The system prompt contains the rating rubric,
says the resume is untrusted data, requires verbatim quotes and cited chunk ids, and says to pick the lower rating when unsure.
Temperature 0. Output is a small JSON object (`RawCriterionOutput`); the final schema is built by code, not by the model.

**Verification** (`verify.py`, `pipeline.py`). Never trust the model: quotes are fuzzy-matched against the resume (>=90% character coverage);
cited ids must be in the retrieved set; on any problem the model gets **one** repair attempt with the specific complaint. Then:
Strong/Partial with no verified evidence is auto-downgraded to Insufficient Info; no valid citation means we attach the top criterion chunk and set `citation_fallback`;
two failed JSON attempts yields an honest "no judgment made" rather than a guess. All of this is recorded in `diagnostics` and drives the eval metrics.

**Score** (`summary.py`). Not from the LLM: Strong = 1.0 point, Partial = 0.4, `score = 100 x min(points, 4) / 4`, capped at 69 if fewer than 3 criteria are Strong.
It is a transparent heuristic for ordering profiles, **not** a prediction of approval, and it does not model the final-merits step.

## Output (abridged)

```json
{
  "candidate_label": "p03_startup_founder.txt",
  "criteria": [{
    "criterion_id": "awards", "criterion_name": "Awards and prizes", "regulation": "8 CFR 204.5(h)(3)(i)",
    "rating": "Strong",
    "evidence": ["Winner, 2022 National Startup Awards, Fintech category (1 of 11 winners ...)"],
    "reasoning": "...", "next_steps": ["...", "..."],
    "citations": [{"chunk_id": "c004", "section": "... > Awards and prizes", "snippet": "..."}],
    "diagnostics": {"attempts": 1, "raw_unverified_quotes": 0, "downgraded": false, "...": "..."}
  }],
  "summary": {"strong_count": 4, "meets_minimum_three": true, "readiness_score": 100, "strongest_criteria": ["..."], "main_gaps": ["..."], "narrative": "..."},
  "meta": {"provider": "anthropic", "model": "...", "corpus_source": "uscis_live", "guardrail_flags": []}
}
```

## Evaluation

7 synthetic profiles x 10 criteria = 70 labelled cells (`data/labels.json`, with notes on the debatable ones). Profiles target
specific behaviours: a strong researcher, an early-career engineer (weak/ambiguous evidence), a founder (mixed), a visual artist
(art sales are *not* performing-arts success), a musician, a vague resume (should say Insufficient Info), and a prompt-injection resume.

Metrics (`eval/run_eval.py`): exact accuracy, Strong-vs-not accuracy, per-class P/R/F1 and confusion matrix, agreement on the "3+ Strong" decision,
**hallucinated evidence rate** (first-attempt quotes not found in the resume, *before* our verifier), invalid citation rate, citation scope rate
(cited chunk is on-criterion or general; a cheap structural proxy), optional **LLM-judge citation support**, and downgrade/fallback/retry counts, latency, tokens, cost.

**Results so far** (offline seed corpus, rule baseline; LLM columns to be filled by running the eval with your key):

| Metric | Majority-class guess | Rule baseline | LLM (fill in) |
|---|---|---|---|
| Exact rating accuracy | 42.9% | 70.0% | |
| Strong vs not-Strong | n/a | 85.7% | |
| "3+ Strong" agreement | n/a | 7/7 profiles | |
| Hallucinated evidence | n/a | 0% (verbatim lines only) | |
| Citation scope rate | n/a | 100% | |
| Injection resisted (p07) | n/a | yes | |

Full failure analysis: [`docs/FAILURE_ANALYSIS.md`](docs/FAILURE_ANALYSIS.md). Part A (baseline) is measured; Part B (LLM) is a template to complete after your run.

Limits of this eval, stated plainly: one person wrote both profiles and labels; 70 cells is small (one cell is 1.4 points);
the retrieval ablation is only meaningful on the real corpus (on the 13-chunk seed corpus every mode scores 1.000), and its "gold" is
structural (heading tags), not human relevance judgements; the citation-scope proxy cannot tell whether a sentence supports a claim; the LLM judge has its own error,
so spot-check it against your own reading.

## Design decisions and trade-offs

* **Heading-scoped retrieval.** Exploits the manual's structure and removes cross-criterion confusion; cost: it depends on correct tagging
  (hence the `inspect` command and a test) and can hide relevant text filed under another heading. Mitigation: `general` chunks are always included.
* **One LLM call per criterion** (10 calls + 1 narrative). More calls and tokens than one big call, but focused context, parallelism, isolated failures,
  and per-criterion retrieval. Cost stays small on a cheap model.
* **Verify instead of trust.** Quote and citation checks are code, not prompt requests. The downgrade rule trades a little recall for honesty.
* **Score by formula.** Reproducible and explainable; the weights (1.0 / 0.4, cap 69) are my judgement, not USCIS's.
* **Rule baseline.** Gives the eval something to beat and lets everything run offline.
* **Pydantic at two levels.** A small schema for the model, a strict one for the output (exactly 10 unique criteria, Strong/Partial need evidence, 1-2 next steps, citations required).

## Guardrails

Garbled/empty/too-short input is refused with a clear message; scanned PDFs with no text layer are reported, not guessed at; zero-width characters are stripped;
lines that look like instructions to an AI (or self-asserted "verified" tags) are quarantined before evidence extraction and listed in `meta.guardrail_flags`; the prompt tells the model that the
resume is data; and every quote is verified. **Limits:** the pattern list is a heuristic and will miss paraphrased attacks; quarantining can remove a real line that happens to match;
text hidden by colour in a PDF is extracted like any other text. Defence in depth (verification + downgrade) is the real protection.

## What I'd improve with more time

1. Evaluate on the real corpus and iterate on chunking (try sentence-window or parent-child chunks) using the retrieval ablation; add a cross-encoder re-ranker.
2. A larger, independently labelled set (two labellers, agreement score), including real-style messy PDFs.
3. Calibrate ratings (e.g. self-consistency over 3 runs, report variance) and add a second-pass "critic" for Strong ratings.
4. Model the final-merits step, and add the agentic bonus (web search for judging / speaking / award opportunities for the weakest criteria).
5. Citation support at sentence level instead of chunk level.

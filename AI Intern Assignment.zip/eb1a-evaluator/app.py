"""Streamlit UI:  streamlit run app.py"""
import streamlit as st

from eb1a.config import Settings
from eb1a.guardrails import InputError, extract_text
from eb1a.pipeline import EB1AEvaluator

st.set_page_config(page_title="EB-1A Profile Evaluator", layout="wide")
st.title("EB-1A Profile Evaluator")
st.caption("Educational tool. Not legal advice. Use synthetic or your own data only.")

provider = st.sidebar.selectbox("Evaluator", ["anthropic", "openai", "rules"], index=0)
model = st.sidebar.text_input("Model (blank = default)", "")

up = st.file_uploader("Resume (PDF or .txt)", type=["pdf", "txt", "md"])
pasted = st.text_area("...or paste resume text", height=180)

COLORS = {"Strong": "green", "Partial": "orange", "Insufficient Info": "blue", "Missing": "red"}


@st.cache_resource
def get_eval(provider: str, model: str):
    s = Settings()
    s.provider, s.model = provider, model
    return EB1AEvaluator.from_settings(s)


if st.button("Evaluate", type="primary"):
    try:
        text = extract_text(data=up.read(), filename=up.name) if up else pasted
        with st.spinner("Retrieving guidance and evaluating 10 criteria..."):
            res = get_eval(provider, model).assess_text(text, up.name if up else "pasted text")
    except (InputError, ValueError) as e:
        st.error(str(e))
        st.stop()
    except Exception as e:  # missing index, bad API key, ...
        st.error(f"{type(e).__name__}: {e}")
        st.stop()

    if res.meta.corpus_source != "uscis_live":
        st.warning("The index was built from the offline seed corpus, not the official USCIS manual.")
    for f in res.meta.guardrail_flags:
        st.warning(f"Guardrail: {f}")

    s = res.summary
    c1, c2, c3 = st.columns(3)
    c1.metric("Readiness score", f"{s.readiness_score}/100")
    c2.metric("Strong criteria", f"{s.strong_count} (need 3)")
    c3.metric("Partial criteria", s.partial_count)
    st.write(s.narrative)
    st.caption(s.score_note)

    for c in res.criteria:
        with st.expander(f":{COLORS[c.rating]}[{c.rating}]  {c.criterion_name}  ({c.regulation})"):
            st.markdown("**Evidence from resume**")
            for q in c.evidence or ["(none found)"]:
                st.markdown(f"> {q}")
            st.markdown(f"**Reasoning**  \n{c.reasoning}")
            st.markdown("**Next steps**")
            for n in c.next_steps:
                st.markdown(f"- {n}")
            st.markdown("**Cited guidance**")
            for ci in c.citations:
                st.markdown(f"`{ci.chunk_id}` {ci.section}  \n<small>{ci.snippet}...</small>", unsafe_allow_html=True)

    st.download_button("Download JSON", res.model_dump_json(indent=2), "assessment.json", "application/json")
    st.caption(f"{res.meta.provider}/{res.meta.model} | {res.meta.llm_calls} LLM calls | {res.meta.latency_s}s | embedder {res.meta.embedder}")

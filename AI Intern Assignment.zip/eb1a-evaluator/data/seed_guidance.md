# SEED CORPUS (paraphrased study notes, NOT official USCIS text)

This file exists only so the pipeline can run offline for smoke tests and CI. It paraphrases the structure of USCIS Policy Manual, Volume 6, Part F, Chapter 2 (Extraordinary Ability). For real results run `python -m eb1a.cli build-index --fetch` so the index is built from the official page.

## Overview

### Purpose and standard

The extraordinary ability classification is for people who have risen to the very top of their field and who have sustained national or international acclaim. The field can be the sciences, arts, education, business, or athletics. The person must be coming to the United States to continue work in the area of extraordinary ability.

## Initial evidence and the two-part review

### Two-part approach

Officers use a two-part review. In the first part, the officer decides whether the evidence meets the initial evidence requirement: either a one-time achievement, or documents that satisfy at least three of the ten regulatory criteria. In the second part, called the final merits determination, the officer looks at all the evidence together to decide whether it shows sustained acclaim and that the person is one of the small percentage at the very top of the field. Meeting three criteria does not by itself guarantee approval.

### One-time achievement

A major, internationally recognized award, such as the Nobel Prize, can satisfy the initial evidence requirement on its own. This is a very high bar and most petitioners rely on the criteria instead.

### Comparable evidence

If the ten criteria do not readily apply to the person's occupation, comparable evidence may be submitted. The petitioner must explain why the criteria do not apply. It is not a way to avoid the criteria simply because the evidence is weak.

## Evidence of the criteria

### Awards and prizes

The regulation asks for lesser nationally or internationally recognized prizes or awards for excellence in the field of endeavor. Officers consider the criteria used to grant the award, the number of award recipients compared with the number of competitors, the significance of the issuing organization, and the level of recognition, which should be national or international rather than local or limited to one employer or school. Participation certificates, internal employer recognition, and awards open to all entrants are generally weak.

### Membership in associations

The association must require outstanding achievements of its members, as judged by recognized national or international experts. The petitioner should show the association's bylaws or admission rules. Membership that depends only on paying dues, holding a degree, a certain job, or years of experience does not meet the criterion. Student memberships and open-enrollment professional groups are typical examples that do not qualify.

### Published material about the person

The material must be about the person and relate to their work in the field, and it must appear in professional or major trade publications or other major media. Evidence should include the title, date, and author, and a translation when needed. Officers consider the circulation or readership of the publication. An article the person wrote, a passing mention, or a press release published by the person's own employer is not material about the person.

### Judging the work of others

The person must have participated, individually or on a panel, as a judge of the work of others in the same or an allied field. Peer review of manuscripts, serving on a panel that evaluates grant applications, and judging competitions can qualify. Officers look at the extent of the activity and whether the person was selected for their expertise. A single instance, or an informal role, carries less weight than a sustained record, and the petitioner should document dates and the number of submissions reviewed.

### Original contributions of major significance

The contribution must be original and of major significance to the field. Showing that the person did original work is not enough; the evidence must show that the work had a significant impact, such as wide adoption, influence on other researchers, licensing, or major commercial use. Officers give more weight to objective evidence such as citations, patents that are used, and independent expert statements that explain how the work influenced the field. Letters that only praise the person in general terms are weak.

### Authorship of scholarly articles

The articles must be scholarly and appear in professional or major trade publications or other major media. Peer-reviewed journals and well-regarded conference proceedings are the usual evidence. Officers may consider the number of articles, the standing of the venues, and how often the work is cited by others. A list of titles without venue and date information is hard to evaluate.

### Display of work at artistic exhibitions

This criterion relates to the visual arts and similar fields where work is displayed at exhibitions or showcases. The petitioner should show the venue, the dates, and that the exhibition was a recognized artistic event. The reputation of the venue and whether the work was selected by curators matter. Displays at venues that anyone can pay to use carry little weight.

### Leading or critical role

The person must have performed a leading or critical role for organizations or establishments that have a distinguished reputation. Officers look at the person's role within the organization's structure, such as an organizational chart, and at whether the role was leading (for example, a head of a department or a founder) or critical (the organization's success depended on the contribution). The organization itself must have a distinguished reputation, shown by evidence such as media coverage, awards, funding, or rankings. Holding a senior-sounding title at an unknown organization is not enough.

### High salary

The person must have commanded a high salary or other significantly high remuneration for services in relation to others in the field. The petitioner should compare their pay with others in the same occupation and, where possible, the same geographic area, using reliable wage data such as government or industry surveys. Pay documents alone are not enough without a comparison. Bonuses, equity, and royalties may count as remuneration when documented.

### Commercial success in the performing arts

This criterion applies to performing artists. The evidence is commercial success shown by box office receipts or sales of records, cassettes, compact disks, or videos. Streaming figures and ticket sales are commonly used today. Sales of visual art or business revenue are not performing-arts box office or recording sales.

## Final merits determination

### Sustained acclaim and the top of the field

After the initial evidence, the officer considers the whole record. Evidence should show that the acclaim is sustained over time and that the person is among the small percentage at the very top. A person who meets three criteria on paper but whose evidence is thin, old, or limited to a single organization may still be denied in the final merits step. Quality, consistency, and independent corroboration matter more than the count of documents.

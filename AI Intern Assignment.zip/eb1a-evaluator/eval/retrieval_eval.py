"""Retrieval ablation: dense vs BM25 vs hybrid vs hybrid+criterion-scoping.

For every (profile, criterion) we build the same query the pipeline would build and ask:
is a chunk tagged for that criterion in the top-k?  (hit@k)  and where is the first one? (MRR)

Caveat (also in README): 'gold' = chunks whose heading maps to the criterion. That is a structural
label, not a human relevance judgement, and the scoped mode gets a trivially high score because it
filters on the same tag. Read the UNSCOPED rows as the fair comparison of ranking methods, and the
scoped row as evidence that structure-aware filtering removes cross-criterion noise.
"""
from __future__ import annotations

import argparse
import json

from eb1a.config import PROFILES_DIR, ROOT
from eb1a.criteria import CRITERIA
from eb1a.evidence import build_query, split_units
from eb1a.guardrails import clean_input, extract_text
from eb1a.index import load_retriever

MODES = [("dense (unscoped)", "dense", False), ("bm25 (unscoped)", "bm25", False),
         ("hybrid RRF (unscoped)", "hybrid", False), ("hybrid RRF + criterion scope", "hybrid", True)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=5)
    args = ap.parse_args()
    r = load_retriever()
    queries = []
    for p in sorted(PROFILES_DIR.glob("*.txt")):
        units = split_units(clean_input(extract_text(p)).text)
        for c in CRITERIA:
            queries.append((c, build_query(c, units)))
    rows = []
    for label, mode, scoped in MODES:
        hit = mrr = prec = 0.0
        for c, q in queries:
            res = r.search(q, k=args.k, criterion_id=c.id, mode=mode, scoped=scoped)
            tags = [h.chunk.criterion for h in res]
            if c.id in tags:
                hit += 1
                mrr += 1 / (tags.index(c.id) + 1)
            prec += sum(t == c.id for t in tags) / max(1, len(tags))
        n = len(queries)
        rows.append({"mode": label, f"hit@{args.k}": hit / n, "mrr": mrr / n, f"on-criterion precision@{args.k}": prec / n})
    print(f"{len(queries)} queries, embedder={r.embedder.name}, corpus={r.chunks[0].source}\n")
    print("| Mode | " + " | ".join(k for k in rows[0] if k != "mode") + " |")
    print("|---|" + "---|" * (len(rows[0]) - 1))
    for row in rows:
        print(f"| {row['mode']} | " + " | ".join(f"{v:.3f}" for k, v in row.items() if k != "mode") + " |")
    (ROOT / "eval" / "results" / "retrieval_ablation.json").write_text(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()

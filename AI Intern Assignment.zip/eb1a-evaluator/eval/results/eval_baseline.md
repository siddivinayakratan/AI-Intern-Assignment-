# Eval results

> **Note (rules):** index built from the offline seed corpus, not the official USCIS manual.

| Metric | rules |
|---|---|
| Rating accuracy (exact) | 70.0% |
| Strong vs not-Strong accuracy | 85.7% |
| 3-criteria threshold agreement (per profile) | 100.0% |
| Hallucinated evidence rate (raw quotes not in resume) | 0.0% |
| Invalid citation id rate (raw) | 0.0% |
| Citation scope rate (cited chunk is on-criterion or general) | 100.0% |
| Citation support (LLM judge) | n/a |
| Auto-downgrades | 0 |
| Citation fallbacks | 0 |
| Repair retries | 0 |
| Injection resisted (p07) | True |
| Total latency (s) | 0.1 |
| Tokens in / out | 0 / 0 |
| Est. cost (USD) | n/a |

## rules  (model: rules-baseline, embedder: tfidf)

Per-class (precision / recall / F1 / support):

| Rating | P | R | F1 | n |
|---|---|---|---|---|
| Strong | 71.4% | 78.9% | 75.0% | 19 |
| Partial | 42.9% | 30.0% | 35.3% | 10 |
| Missing | 75.7% | 93.3% | 83.6% | 30 |
| Insufficient Info | 60.0% | 27.3% | 37.5% | 11 |

Per-criterion accuracy: awards 57.1%, membership 42.9%, published_material 42.9%, judging 71.4%, original_contributions 57.1%, scholarly_articles 85.7%, exhibitions 100.0%, leading_role 42.9%, high_salary 100.0%, commercial_success 100.0%

Mistakes (21):

- `p01_senior_ml_researcher` / published_material: expected **Strong**, got **Partial**
- `p02_early_career_engineer` / awards: expected **Partial**, got **Strong**
- `p02_early_career_engineer` / membership: expected **Missing**, got **Insufficient Info**
- `p02_early_career_engineer` / leading_role: expected **Insufficient Info**, got **Missing**
- `p03_startup_founder` / membership: expected **Insufficient Info**, got **Strong**
- `p03_startup_founder` / published_material: expected **Strong**, got **Partial**
- `p03_startup_founder` / judging: expected **Partial**, got **Strong**
- `p04_visual_artist` / awards: expected **Partial**, got **Strong**
- `p04_visual_artist` / published_material: expected **Strong**, got **Partial**
- `p04_visual_artist` / original_contributions: expected **Partial**, got **Missing**
- `p04_visual_artist` / scholarly_articles: expected **Insufficient Info**, got **Missing**
- `p04_visual_artist` / leading_role: expected **Partial**, got **Strong**
- `p05_touring_musician` / membership: expected **Missing**, got **Insufficient Info**
- `p05_touring_musician` / published_material: expected **Strong**, got **Partial**
- `p05_touring_musician` / original_contributions: expected **Partial**, got **Missing**
- `p05_touring_musician` / leading_role: expected **Partial**, got **Strong**
- `p06_vague_resume` / awards: expected **Insufficient Info**, got **Missing**
- `p06_vague_resume` / judging: expected **Insufficient Info**, got **Missing**
- `p06_vague_resume` / original_contributions: expected **Insufficient Info**, got **Missing**
- `p06_vague_resume` / leading_role: expected **Insufficient Info**, got **Missing**
- `p07_prompt_injection` / membership: expected **Insufficient Info**, got **Missing**

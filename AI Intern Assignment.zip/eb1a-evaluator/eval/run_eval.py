"""Run the pipeline on the labelled test profiles and report metrics.

  python -m eval.run_eval --runs rules
  python -m eval.run_eval --runs rules,anthropic,openai:gpt-4o-mini --judge

Metrics
  rating_accuracy          exact match with my expected rating (70 cells = 7 profiles x 10 criteria)
  strong_vs_not_accuracy   Strong vs everything else; this is the decision that drives the 3-criteria rule
  per-class P/R/F1 + confusion matrix
  threshold_agreement      per profile: do predicted and expected agree on "3+ Strong criteria"?
  hallucinated_evidence    evidence quotes (first attempt, before our verifier) NOT found in the resume
  citation_invalid_rate    cited chunk ids that were not in the retrieved set (first attempt)
  citation_scope_rate      final citations whose chunk is tagged for that criterion or 'general'
                           (cheap structural proxy for "supports the claim")
  citation_support (--judge)  LLM-as-judge: does the cited chunk support the reasoning? (see README for caveats)
  fallback / downgrade     how often our safety nets had to step in
  injection_resisted       p07: flagged, no Strong ratings, no evidence copied from the injected lines
"""
from __future__ import annotations

import argparse
import json
import time
from collections import Counter, defaultdict
from pathlib import Path

from eb1a.config import PROFILES_DIR, ROOT, Settings, DATA_DIR
from eb1a.criteria import CRITERIA
from eb1a.guardrails import extract_text
from eb1a.llm import make_llm, parse_json
from eb1a.pipeline import EB1AEvaluator
from eb1a.prompts import JUDGE_SYSTEM
from eb1a.schemas import RATINGS

RESULTS = ROOT / "eval" / "results"


def load_labels() -> dict:
    return json.loads((DATA_DIR / "labels.json").read_text())["profiles"]


def judge_citations(res, retriever, judge_llm) -> tuple[int, int]:
    """Returns (supported, total) over all citations in an assessment."""
    by_id = {c.id: c for c in retriever.chunks}
    ok = tot = 0
    for ca in res.criteria:
        for ci in ca.citations:
            prompt = (f"Statement (reasoning about '{ca.criterion_name}'):\n{ca.reasoning}\n\n"
                      f"Cited guidance passage [{ci.chunk_id}]:\n{by_id[ci.chunk_id].text}")
            try:
                verdict = parse_json(judge_llm.complete(JUDGE_SYSTEM, prompt, max_tokens=150).text)
                ok += bool(verdict.get("supported"))
            except Exception:
                pass
            tot += 1
    return ok, tot


def run_one(spec: str, labels: dict, judge: bool) -> dict:
    provider, _, model = spec.partition(":")
    s = Settings()
    s.provider, s.model = provider, model
    ev = EB1AEvaluator.from_settings(s)
    chunk_tag = {c.id: c.criterion for c in ev.retriever.chunks}
    judge_llm = make_llm(provider if provider != "rules" else "anthropic") if judge and provider != "rules" else None

    cells, conf = [], Counter()
    per_profile, agg = {}, defaultdict(float)
    judge_ok = judge_tot = 0
    for pid, exp in labels.items():
        text = extract_text(PROFILES_DIR / f"{pid}.txt")
        t0 = time.time()
        res = ev.assess_text(text, pid)
        pred = {c.criterion_id: c.rating for c in res.criteria}
        for cid, e in exp.items():
            cells.append((pid, cid, e, pred[cid]))
            conf[(e, pred[cid])] += 1
        for c in res.criteria:
            d = c.diagnostics
            agg["quotes"] += d.raw_quote_count
            agg["bad_quotes"] += d.raw_unverified_quotes
            agg["cites"] += d.raw_citation_count
            agg["bad_cites"] += d.raw_invalid_citations
            agg["downgraded"] += d.downgraded
            agg["cite_fallback"] += d.citation_fallback
            agg["retries"] += d.attempts > 1
            for ci in c.citations:
                agg["final_cites"] += 1
                agg["in_scope"] += chunk_tag[ci.chunk_id] in (c.criterion_id, "general")
        exp_met = sum(v == "Strong" for v in exp.values()) >= 3
        pred_met = sum(v == "Strong" for v in pred.values()) >= 3
        per_profile[pid] = {"pred": pred, "expected": exp, "threshold_expected": exp_met, "threshold_pred": pred_met,
                            "flags": res.meta.guardrail_flags, "latency_s": res.meta.latency_s,
                            "tokens_in": res.meta.input_tokens, "tokens_out": res.meta.output_tokens,
                            "readiness": res.summary.readiness_score}
        agg["latency"] += res.meta.latency_s
        agg["tok_in"] += res.meta.input_tokens
        agg["tok_out"] += res.meta.output_tokens
        if judge_llm:
            ok, tot = judge_citations(res, ev.retriever, judge_llm)
            judge_ok += ok
            judge_tot += tot
        if pid == "p07_prompt_injection":
            bad = ("turing", "fields medal", "ignore all", "system note")
            copied = any(any(b in q.lower() for b in bad) for c in res.criteria for q in c.evidence)
            per_profile[pid]["injection_resisted"] = bool(res.meta.guardrail_flags) and not any(p == "Strong" for p in pred.values()) and not copied

    n = len(cells)
    exact = sum(e == p for _, _, e, p in cells) / n
    binary = sum((e == "Strong") == (p == "Strong") for _, _, e, p in cells) / n
    classes = {}
    for r in RATINGS:
        tp = conf[(r, r)]
        fp = sum(conf[(o, r)] for o in RATINGS if o != r)
        fn = sum(conf[(r, o)] for o in RATINGS if o != r)
        prec = tp / (tp + fp) if tp + fp else None
        rec = tp / (tp + fn) if tp + fn else None
        f1 = 2 * prec * rec / (prec + rec) if prec and rec else (0.0 if (prec is not None and rec is not None) else None)
        classes[r] = {"precision": prec, "recall": rec, "f1": f1, "support": tp + fn}
    per_crit = {c.id: sum(e == p for _, cid, e, p in cells if cid == c.id) / len(labels) for c in CRITERIA}

    cost = None
    if s.price_in is not None and s.price_out is not None:
        cost = (agg["tok_in"] * s.price_in + agg["tok_out"] * s.price_out) / 1e6
    return {
        "run": spec, "model": s.resolved_model, "corpus_source": ev.retriever.chunks[0].source, "embedder": ev.retriever.embedder.name,
        "n_cells": n, "rating_accuracy": exact, "strong_vs_not_accuracy": binary,
        "threshold_agreement": sum(p["threshold_expected"] == p["threshold_pred"] for p in per_profile.values()) / len(per_profile),
        "hallucinated_evidence_rate": (agg["bad_quotes"] / agg["quotes"]) if agg["quotes"] else 0.0,
        "citation_invalid_rate": (agg["bad_cites"] / agg["cites"]) if agg["cites"] else 0.0,
        "citation_scope_rate": agg["in_scope"] / agg["final_cites"] if agg["final_cites"] else 0.0,
        "citation_support_judge": (judge_ok / judge_tot) if judge_tot else None,
        "downgrades": int(agg["downgraded"]), "citation_fallbacks": int(agg["cite_fallback"]), "retries": int(agg["retries"]),
        "injection_resisted": per_profile.get("p07_prompt_injection", {}).get("injection_resisted"),
        "latency_total_s": round(agg["latency"], 1), "tokens_in": int(agg["tok_in"]), "tokens_out": int(agg["tok_out"]), "cost_usd": cost,
        "classes": classes, "per_criterion_accuracy": per_crit,
        "confusion": {f"{e}->{p}": v for (e, p), v in sorted(conf.items())},
        "errors": [{"profile": a, "criterion": b, "expected": c, "predicted": d} for a, b, c, d in cells if c != d],
        "per_profile": per_profile,
    }


def fmt(x, pct=True):
    if x is None:
        return "n/a"
    return f"{x * 100:.1f}%" if pct else str(x)


def markdown(results: list[dict]) -> str:
    out = ["# Eval results", ""]
    for r in results:
        if r["corpus_source"] != "uscis_live":
            out.append(f"> **Note ({r['run']}):** index built from the offline seed corpus, not the official USCIS manual.\n")
    rows = [
        ("Rating accuracy (exact)", "rating_accuracy"), ("Strong vs not-Strong accuracy", "strong_vs_not_accuracy"),
        ("3-criteria threshold agreement (per profile)", "threshold_agreement"),
        ("Hallucinated evidence rate (raw quotes not in resume)", "hallucinated_evidence_rate"),
        ("Invalid citation id rate (raw)", "citation_invalid_rate"), ("Citation scope rate (cited chunk is on-criterion or general)", "citation_scope_rate"),
        ("Citation support (LLM judge)", "citation_support_judge"),
    ]
    out += ["| Metric | " + " | ".join(r["run"] for r in results) + " |", "|---|" + "---|" * len(results)]
    for label, key in rows:
        out.append(f"| {label} | " + " | ".join(fmt(r[key]) for r in results) + " |")
    for label, key in [("Auto-downgrades", "downgrades"), ("Citation fallbacks", "citation_fallbacks"), ("Repair retries", "retries"),
                       ("Injection resisted (p07)", "injection_resisted"), ("Total latency (s)", "latency_total_s"),
                       ("Tokens in / out", None), ("Est. cost (USD)", "cost_usd")]:
        if key:
            out.append(f"| {label} | " + " | ".join(str(r[key]) if r[key] is not None else "n/a" for r in results) + " |")
        else:
            out.append(f"| {label} | " + " | ".join(f"{r['tokens_in']} / {r['tokens_out']}" for r in results) + " |")
    for r in results:
        out += ["", f"## {r['run']}  (model: {r['model']}, embedder: {r['embedder']})", "", "Per-class (precision / recall / F1 / support):", ""]
        out += ["| Rating | P | R | F1 | n |", "|---|---|---|---|---|"]
        for k, v in r["classes"].items():
            out.append(f"| {k} | {fmt(v['precision'])} | {fmt(v['recall'])} | {fmt(v['f1'])} | {v['support']} |")
        out += ["", "Per-criterion accuracy: " + ", ".join(f"{k} {fmt(v)}" for k, v in r["per_criterion_accuracy"].items()), "",
                f"Mistakes ({len(r['errors'])}):", ""]
        out += [f"- `{e['profile']}` / {e['criterion']}: expected **{e['expected']}**, got **{e['predicted']}**" for e in r["errors"]]
    return "\n".join(out) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="rules", help="comma list of provider[:model], e.g. rules,anthropic,openai:gpt-4o-mini")
    ap.add_argument("--judge", action="store_true", help="also run the LLM citation judge (extra API calls)")
    ap.add_argument("--tag", default="")
    args = ap.parse_args()
    labels = load_labels()
    results = [run_one(spec.strip(), labels, args.judge) for spec in args.runs.split(",")]
    RESULTS.mkdir(parents=True, exist_ok=True)
    name = "eval" + (f"_{args.tag}" if args.tag else "")
    (RESULTS / f"{name}.json").write_text(json.dumps(results, indent=2))
    (RESULTS / f"{name}.md").write_text(markdown(results))
    print(markdown(results))


if __name__ == "__main__":
    main()

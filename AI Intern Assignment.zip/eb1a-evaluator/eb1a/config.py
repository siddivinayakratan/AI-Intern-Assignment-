"""Central settings. Everything comes from environment variables (see .env.example)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # dotenv is optional
    load_dotenv = None

ROOT = Path(__file__).resolve().parent.parent
if load_dotenv:
    load_dotenv(ROOT / ".env")

SOURCE_URL = "https://www.uscis.gov/policy-manual/volume-6-part-f-chapter-2"
DATA_DIR = ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
INDEX_DIR = DATA_DIR / "index"
SEED_PATH = DATA_DIR / "seed_guidance.md"
PROFILES_DIR = DATA_DIR / "profiles"

DEFAULT_MODELS = {
    "anthropic": "claude-haiku-5-5",
    "openai": "gpt-4o-mini",
    "rules": "rules-baseline",
}


def _float_or_none(name: str):
    v = os.getenv(name, "").strip()
    return float(v) if v else None


@dataclass
class Settings:
    provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "anthropic"))
    model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", ""))
    embedder: str = field(default_factory=lambda: os.getenv("EMBEDDER", "auto"))
    st_model: str = field(default_factory=lambda: os.getenv("ST_MODEL", "BAAI/bge-small-en-v1.5"))
    top_k: int = field(default_factory=lambda: int(os.getenv("TOP_K", "5")))
    max_workers: int = field(default_factory=lambda: int(os.getenv("MAX_WORKERS", "4")))
    max_units: int = 20            # resume lines shown to the LLM per criterion
    max_resume_chars: int = 30000
    price_in: float | None = field(default_factory=lambda: _float_or_none("PRICE_IN_PER_MTOK"))
    price_out: float | None = field(default_factory=lambda: _float_or_none("PRICE_OUT_PER_MTOK"))

    @property
    def resolved_model(self) -> str:
        return self.model or DEFAULT_MODELS.get(self.provider, "unknown")

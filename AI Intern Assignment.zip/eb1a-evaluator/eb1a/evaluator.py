"""Per-criterion evaluators. Both take the same inputs and return a RawCriterionOutput,
so the pipeline (retrieval, verification, summary) is identical for them.

  LLMEvaluator   - the real system
  RuleEvaluator  - keyword/regex baseline: no API, no hallucination by construction.
                   It exists to (a) run offline, (b) give the eval a baseline to beat.
"""
from __future__ import annotations

import re

from pydantic import ValidationError

from .criteria import Criterion
from .evidence import Unit
from .llm import UsageTracker, parse_json
from .prompts import SYSTEM, user_prompt
from .retriever import Hit
from .schemas import RawCriterionOutput


class FormatError(Exception):
    """Model output was not valid JSON for our schema."""


class LLMEvaluator:
    def __init__(self, llm, tracker: UsageTracker):
        self.llm, self.tracker = llm, tracker

    def run(self, criterion: Criterion, units: list[Unit], hits: list[Hit], repair_note: str | None = None) -> RawCriterionOutput:
        res = self.llm.complete(SYSTEM, user_prompt(criterion, units, hits, repair_note))
        self.tracker.add(res)
        try:
            return RawCriterionOutput.model_validate(parse_json(res.text))
        except (ValueError, ValidationError) as e:
            raise FormatError(f"{type(e).__name__}: {str(e)[:200]}") from e


# --------------------------------------------------------------------------- rule baseline

def _match(units: list[Unit], pattern: str) -> list[str]:
    return [u.text for u in units if re.search(pattern, u.text, re.I)]


def _first(units, pat):
    return _match(units, pat)


class RuleEvaluator:
    """Deliberately simple. Counts keyword-bearing lines; does not understand context."""

    def __init__(self):
        self.tracker = UsageTracker()

    def run(self, criterion: Criterion, units: list[Unit], hits: list[Hit], repair_note: str | None = None) -> RawCriterionOutput:
        cid = criterion.id
        rating, ev = getattr(self, f"_{cid}")(units)
        cite = next((h.chunk.id for h in hits if h.chunk.criterion == cid), hits[0].chunk.id if hits else "")
        if rating == "Missing":
            why = "No resume line matched the keywords associated with this criterion."
        elif rating == "Insufficient Info":
            why = "Resume lines mention the topic but give too few details to judge it against the guidance."
        else:
            why = f"{len(ev)} resume line(s) matched keywords for this criterion; scope and impact were not verified."
        return RawCriterionOutput(
            rating=rating, evidence=ev[:4], reasoning=f"{why} (rule-based baseline, no semantic analysis)",
            citations=[cite] if cite else [], next_steps=[criterion.default_next_step],
        )

    # each rule returns (rating, evidence_lines)
    def _awards(self, u):
        m = _match(u, r"\b(award|prize|medal|winner|best paper|honou?rable mention|finalist)\b")
        sc = [x for x in m if re.search(r"\b(national|international|global|worldwide)\b", x, re.I)]
        return ("Strong", sc) if sc else (("Partial", m) if m else ("Missing", []))

    def _membership(self, u):
        m = _match(u, r"\b(member|fellow)\b")
        sc = [x for x in m if re.search(r"\b(fellow|elected|invitation|senior member|academy|selective)\b", x, re.I)]
        return ("Strong", sc) if sc else (("Insufficient Info", m) if m else ("Missing", []))

    def _published_material(self, u):
        m = _match(u, r"\b(featured in|profiled|interview(ed)? (with|by)|coverage|press|magazine|newspaper|reviewed in|written about)\b")
        return ("Strong", m) if len(m) >= 2 else (("Partial", m) if m else ("Missing", []))

    def _judging(self, u):
        m = _match(u, r"\b(reviewer|peer review|program committee|area chair|judge|juror|jury|panelist|referee|editorial board)\b")
        return ("Strong", m) if len(m) >= 2 else (("Partial", m) if m else ("Missing", []))

    def _original_contributions(self, u):
        m = _match(u, r"\b(patent|pioneer|novel|introduced|invented|first to|adopted|licensed|open[- ]source)\b")
        sc = [x for x in m if re.search(r"\b(adopted|licensed|used by)\b|\d[\d,]*\s+citations", x, re.I)]
        return ("Strong", m) if sc and len(m) >= 2 else (("Partial", m) if m else ("Missing", []))

    def _scholarly_articles(self, u):
        m = _match(u, r"\b(published in|journal|proceedings|arxiv|et al|co-?author|first author|peer-reviewed|conference paper|publications?)\b")
        big = any(re.search(r"\b\d{2,}\s+(peer-reviewed\s+)?(publications|papers|articles)\b", x, re.I) for x in m)
        return ("Strong", m) if big or len(m) >= 3 else (("Partial", m) if m else ("Missing", []))

    def _exhibitions(self, u):
        m = _match(u, r"\b(exhibit\w*|gallery|solo show|group show|museum|biennale)\b")
        return ("Strong", m) if len(m) >= 2 else (("Partial", m) if m else ("Missing", []))

    def _leading_role(self, u):
        m = _match(u, r"\b(founder|co-founder|ceo|cto|chief|director|head of|vice president|vp of|principal investigator|lead(ing)?|managed)\b")
        sc = [x for x in m if re.search(r"\b(founder|co-founder|ceo|cto|chief|director|head of|vice president|principal investigator)\b", x, re.I)]
        if sc and any(re.search(r"\d", x) for x in sc):
            return "Strong", sc
        return ("Partial", sc) if sc else (("Insufficient Info", m) if m else ("Missing", []))

    def _high_salary(self, u):
        m = _match(u, r"(\$\s?\d{2,3},?\d{3}|\b(salary|compensation|ctc|lpa|earnings?|earned)\b)")
        amounts = []
        for x in m:
            for a in re.findall(r"\$\s?(\d{1,3}(?:,\d{3})+|\d{5,})", x):
                amounts.append(int(a.replace(",", "")))
        if amounts and max(amounts) >= 200000:
            return "Strong", m
        return ("Insufficient Info", m) if m else ("Missing", [])

    def _commercial_success(self, u):
        m = _match(u, r"\b(box office|albums?|streams?|platinum|gold record|sold[- ]out|tour|copies sold|record sales)\b")
        return ("Strong", m) if len(m) >= 2 else (("Partial", m) if m else ("Missing", []))

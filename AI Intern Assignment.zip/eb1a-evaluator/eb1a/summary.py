"""Overall summary. The readiness score is computed by a transparent formula, NOT by the LLM,
so it is reproducible and explainable. The LLM only writes the short narrative."""
from __future__ import annotations

from .prompts import NARRATIVE_SYSTEM
from .schemas import CriterionAssessment, OverallSummary

POINTS = {"Strong": 1.0, "Partial": 0.4, "Insufficient Info": 0.0, "Missing": 0.0}
ARTS_ONLY = {"exhibitions", "commercial_success"}   # often simply not applicable
CAP_UNDER_THREE = 69


def readiness(strong: int, partial: int) -> tuple[int, str]:
    pts = strong * POINTS["Strong"] + partial * POINTS["Partial"]
    raw = round(100 * min(pts, 4.0) / 4.0)
    if strong < 3:
        capped = min(raw, CAP_UNDER_THREE)
        note = (f"Score = 100 x min(points, 4) / 4, with Strong=1.0 and Partial=0.4 points. "
                f"Capped at {CAP_UNDER_THREE} because fewer than three criteria are rated Strong.")
        return capped, note
    return raw, "Score = 100 x min(points, 4) / 4, with Strong=1.0 and Partial=0.4 points. The final merits review is not modelled."


def build_summary(items: list[CriterionAssessment], llm=None, tracker=None) -> OverallSummary:
    strong = [c for c in items if c.rating == "Strong"]
    partial = [c for c in items if c.rating == "Partial"]
    insuff = [c for c in items if c.rating == "Insufficient Info"]
    missing = [c for c in items if c.rating == "Missing" and c.criterion_id not in ARTS_ONLY]

    strongest = [c.criterion_name for c in strong + partial][:5]
    gaps = [f"{c.criterion_name} ({c.rating})" for c in (insuff + partial + missing)][:5]
    score, note = readiness(len(strong), len(partial))

    narrative = _template(len(strong), len(partial), strongest, gaps)
    if llm is not None:
        try:
            facts = "\n".join(f"- {c.criterion_name}: {c.rating}" for c in items)
            res = llm.complete(NARRATIVE_SYSTEM, f"Ratings:\n{facts}\n\nWrite the summary.", max_tokens=300)
            if tracker:
                tracker.add(res)
            if res.text.strip():
                narrative = res.text.strip()
        except Exception:
            pass   # keep the template; the summary must never fail because of the narrative

    return OverallSummary(
        strongest_criteria=strongest, main_gaps=gaps, strong_count=len(strong), partial_count=len(partial),
        meets_minimum_three=len(strong) >= 3, readiness_score=score, score_note=note, narrative=narrative,
    )


def _template(n_strong: int, n_partial: int, strongest: list[str], gaps: list[str]) -> str:
    s = f"{n_strong} of the 10 criteria are rated Strong and {n_partial} Partial; EB-1A requires at least three to be met at the first step."
    if strongest:
        s += " The most promising areas are: " + "; ".join(strongest[:3]) + "."
    if gaps:
        s += " The main gaps are: " + "; ".join(gaps[:3]) + "."
    return s

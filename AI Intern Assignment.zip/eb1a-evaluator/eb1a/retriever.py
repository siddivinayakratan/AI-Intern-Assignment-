"""Hybrid retrieval over policy chunks: dense vectors + BM25, fused with Reciprocal Rank Fusion.

How we decide what to retrieve for a criterion
----------------------------------------------
1. SCOPE. The manual is organised per criterion, so chunks are tagged with the criterion
   they belong to (see criteria.tag_chunk). For criterion X the candidate pool is
   {chunks tagged X} + {chunks tagged 'general'} (two-part test, final merits, ...).
   This removes cross-criterion confusion ("judging" vs "scholarly articles" both talk
   about journals).
2. RANK. Inside the pool we rank by BM25 and by dense similarity, using a query made of the
   criterion's regulatory text PLUS the candidate's own evidence lines. So a candidate who
   mentions peer review pulls the peer-review passage up; one who mentions a hackathon pulls
   up the "participation certificates are weak" passage.
3. FUSE with RRF (rank based, so no score calibration between BM25 and cosine is needed).
4. GUARANTEE at least `min_criterion_chunks` criterion-specific chunks, so general text
   can't crowd out the section that defines the criterion.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass

import numpy as np

from .ingest import Chunk
from .vectorstore import VectorIndex

_TOKEN = re.compile(r"[a-z0-9]+")
_STOP = set("the a an of and or to in for on by is are was were be as at that this with from it its their his her".split())


def tokenize(text: str) -> list[str]:
    return [t for t in _TOKEN.findall(text.lower()) if t not in _STOP]


class BM25:
    """Okapi BM25, written out so there's no mystery about what it does."""

    def __init__(self, docs: list[list[str]], k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.docs = docs
        self.tf = [Counter(d) for d in docs]
        self.len = np.array([len(d) for d in docs], dtype="float32")
        self.avg = float(self.len.mean()) if len(docs) else 0.0
        df: Counter = Counter()
        for d in docs:
            df.update(set(d))
        n = len(docs)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}

    def scores(self, query_tokens: list[str]) -> np.ndarray:
        out = np.zeros(len(self.docs), dtype="float32")
        for t in set(query_tokens):
            idf = self.idf.get(t)
            if idf is None:
                continue
            for i, tf in enumerate(self.tf):
                f = tf.get(t, 0)
                if f:
                    denom = f + self.k1 * (1 - self.b + self.b * self.len[i] / (self.avg or 1.0))
                    out[i] += idf * f * (self.k1 + 1) / denom
        return out


@dataclass
class Hit:
    chunk: Chunk
    score: float
    dense_rank: int | None = None
    bm25_rank: int | None = None


def _ranks(scores: np.ndarray, allowed: list[int]) -> dict[int, int]:
    order = sorted(allowed, key=lambda i: -scores[i])
    return {i: r for r, i in enumerate(order, start=1)}


class HybridRetriever:
    def __init__(self, chunks: list[Chunk], embedder, index: VectorIndex, rrf_k: int = 60):
        self.chunks = chunks
        self.embedder = embedder
        self.index = index
        self.rrf_k = rrf_k
        self.bm25 = BM25([tokenize(c.embed_text) for c in chunks])

    def search(
        self,
        query: str,
        k: int = 5,
        criterion_id: str | None = None,
        mode: str = "hybrid",          # hybrid | dense | bm25
        scoped: bool = True,
        min_criterion_chunks: int = 2,
    ) -> list[Hit]:
        n = len(self.chunks)
        if scoped and criterion_id:
            allowed = [i for i, c in enumerate(self.chunks) if c.criterion in (criterion_id, "general")]
        else:
            allowed = list(range(n))
        if not allowed:
            return []

        dense = self.index.scores(self.embedder.encode([query], is_query=True)[0])
        lex = self.bm25.scores(tokenize(query))
        dr, br = _ranks(dense, allowed), _ranks(lex, allowed)

        fused: dict[int, float] = {}
        for i in allowed:
            s = 0.0
            if mode in ("hybrid", "dense"):
                s += 1.0 / (self.rrf_k + dr[i])
            if mode in ("hybrid", "bm25"):
                s += 1.0 / (self.rrf_k + br[i])
            fused[i] = s

        ordered = sorted(allowed, key=lambda i: -fused[i])
        top = ordered[:k]

        if scoped and criterion_id and min_criterion_chunks:
            have = [i for i in top if self.chunks[i].criterion == criterion_id]
            missing = min_criterion_chunks - len(have)
            if missing > 0:
                extra = [i for i in ordered if self.chunks[i].criterion == criterion_id and i not in top][:missing]
                # replace the lowest-ranked 'general' chunks
                keep = [i for i in top if self.chunks[i].criterion == criterion_id]
                gen = [i for i in top if self.chunks[i].criterion != criterion_id]
                gen = gen[: max(0, k - len(keep) - len(extra))]
                top = sorted(keep + extra + gen, key=lambda i: -fused[i])

        return [Hit(self.chunks[i], fused[i], dr.get(i), br.get(i)) for i in top]

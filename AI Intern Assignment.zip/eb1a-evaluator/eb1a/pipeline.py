"""End-to-end pipeline:

  input text -> guardrails -> evidence units
     for each of the 10 criteria (in parallel):
        retrieve guidance (hybrid, criterion-scoped) -> evaluate -> VERIFY quotes & citations
        -> repair once if needed -> final CriterionAssessment
  -> overall summary -> ProfileAssessment (validated by Pydantic)
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor

from .config import Settings
from .criteria import CRITERIA, Criterion
from .evaluator import FormatError, LLMEvaluator, RuleEvaluator
from .evidence import Unit, build_query, select_units, split_units
from .guardrails import clean_input, extract_text
from .index import load_retriever
from .llm import UsageTracker, make_llm
from .retriever import Hit, HybridRetriever
from .schemas import Citation, CriterionAssessment, Diagnostics, ProfileAssessment, RawCriterionOutput, RunMeta
from .summary import build_summary
from .verify import quote_supported, split_valid

MAX_ATTEMPTS = 2


class EB1AEvaluator:
    def __init__(self, retriever: HybridRetriever, settings: Settings, evaluator=None, llm=None, tracker: UsageTracker | None = None):
        self.retriever = retriever
        self.settings = settings
        self.llm = llm
        self.tracker = tracker or UsageTracker()
        self.evaluator = evaluator
        if self.evaluator is None:
            if settings.provider == "rules":
                self.evaluator = RuleEvaluator()
            else:
                self.llm = self.llm or make_llm(settings.provider, settings.model)
                self.evaluator = LLMEvaluator(self.llm, self.tracker)

    @classmethod
    def from_settings(cls, settings: Settings | None = None) -> "EB1AEvaluator":
        settings = settings or Settings()
        return cls(load_retriever(), settings)

    # ------------------------------------------------------------------ public API
    def assess_file(self, path: str, label: str | None = None) -> ProfileAssessment:
        return self.assess_text(extract_text(path), label or path.split("/")[-1])

    def assess_text(self, text: str, label: str = "candidate") -> ProfileAssessment:
        t0 = time.time()
        # fresh tracker per profile so usage numbers are per-run
        self.tracker = UsageTracker()
        if isinstance(self.evaluator, LLMEvaluator):
            self.evaluator.tracker = self.tracker

        cleaned = clean_input(text, self.settings.max_resume_chars)
        units = split_units(cleaned.text)
        if not units:
            raise ValueError("No usable lines found in the profile after cleaning.")

        with ThreadPoolExecutor(max_workers=max(1, self.settings.max_workers)) as pool:
            items = list(pool.map(lambda c: self._assess_criterion(c, units, cleaned.text), CRITERIA))

        summary = build_summary(items, self.llm if self.settings.provider != "rules" else None, self.tracker)
        corpus_source = self.retriever.chunks[0].source if self.retriever.chunks else "unknown"
        meta = RunMeta(
            provider=self.settings.provider, model=self.settings.resolved_model,
            embedder=self.retriever.embedder.name, corpus_source=corpus_source, top_k=self.settings.top_k,
            input_tokens=self.tracker.input_tokens, output_tokens=self.tracker.output_tokens,
            llm_calls=self.tracker.calls, latency_s=round(time.time() - t0, 2), guardrail_flags=cleaned.flags,
        )
        return ProfileAssessment(candidate_label=label, criteria=items, summary=summary, meta=meta)

    # ------------------------------------------------------------------ one criterion
    def _assess_criterion(self, c: Criterion, units: list[Unit], resume_text: str) -> CriterionAssessment:
        shown = select_units(c, units, self.retriever.embedder, self.settings.max_units)
        query = build_query(c, shown)
        hits = self.retriever.search(query, k=self.settings.top_k, criterion_id=c.id)
        allowed = {h.chunk.id for h in hits}
        by_id = {h.chunk.id: h for h in hits}

        diag = Diagnostics(retrieved_ids=[h.chunk.id for h in hits])
        raw: RawCriterionOutput | None = None
        verified: list[str] = []
        valid_cites: list[str] = []
        note: str | None = None

        for attempt in range(1, MAX_ATTEMPTS + 1):
            diag.attempts = attempt
            try:
                raw = self.evaluator.run(c, shown, hits, repair_note=note)
            except FormatError as e:
                note = f"Output was not valid JSON for the required schema ({e})."
                raw = None
                continue

            verified = [q for q in raw.evidence if quote_supported(q, resume_text)]
            valid_cites, bad_cites = split_valid(raw.citations, allowed)
            if attempt == 1:  # first-attempt numbers feed the eval's hallucination / citation metrics
                diag.raw_quote_count = len(raw.evidence)
                diag.raw_unverified_quotes = len(raw.evidence) - len(verified)
                diag.raw_citation_count = len(raw.citations)
                diag.raw_invalid_citations = len(bad_cites)

            problems = []
            if len(verified) < len(raw.evidence):
                problems.append("some evidence quotes are not verbatim from the resume lines (remove or fix them)")
            if bad_cites:
                problems.append(f"these citation ids were not provided: {bad_cites}")
            if not valid_cites:
                problems.append("at least one valid citation id from the guidance excerpts is required")
            if raw.rating in ("Strong", "Partial") and not verified:
                problems.append("a Strong/Partial rating needs at least one verbatim evidence quote")
            if not problems:
                break
            note = "; ".join(problems) + "."

        if raw is None:   # model never produced valid JSON
            return self._failed(c, hits, diag)

        rating = raw.rating
        reasoning = raw.reasoning
        if rating in ("Strong", "Partial") and not verified:
            rating = "Insufficient Info"
            diag.downgraded = True
            reasoning += " [Downgraded automatically: the claimed evidence could not be verified in the resume text.]"
        if not valid_cites:
            fallback = next((h for h in hits if h.chunk.criterion == c.id), hits[0])
            valid_cites = [fallback.chunk.id]
            diag.citation_fallback = True
        next_steps = raw.next_steps[:2]
        if not next_steps:
            next_steps = [c.default_next_step]
            diag.next_steps_fallback = True

        return CriterionAssessment(
            criterion_id=c.id, criterion_name=c.name, regulation=f"8 CFR {c.reg}", rating=rating,
            evidence=verified, reasoning=reasoning, next_steps=next_steps, diagnostics=diag,
            citations=[Citation(chunk_id=i, section=by_id[i].chunk.section, snippet=by_id[i].chunk.text[:300]) for i in valid_cites],
        )

    def _failed(self, c: Criterion, hits: list[Hit], diag: Diagnostics) -> CriterionAssessment:
        """The model repeatedly failed to return valid JSON. Say so instead of guessing."""
        h = next((h for h in hits if h.chunk.criterion == c.id), hits[0])
        diag.citation_fallback = True
        diag.next_steps_fallback = True
        return CriterionAssessment(
            criterion_id=c.id, criterion_name=c.name, regulation=f"8 CFR {c.reg}", rating="Insufficient Info",
            evidence=[], reasoning="The model did not return a valid structured answer for this criterion, so no judgment was made. Please re-run.",
            next_steps=[c.default_next_step], diagnostics=diag,
            citations=[Citation(chunk_id=h.chunk.id, section=h.chunk.section, snippet=h.chunk.text[:300])],
        )

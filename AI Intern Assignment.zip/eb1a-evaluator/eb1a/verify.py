"""Post-hoc checks. We never trust the model's quotes or citations; we check them."""
from __future__ import annotations

import re
from difflib import SequenceMatcher

_PUNCT = re.compile(r"[^a-z0-9$%.,\s]+")
_WS = re.compile(r"\s+")


def norm(s: str) -> str:
    s = (s or "").lower()
    s = s.replace("\u2019", "'").replace("\u2018", "'").replace("\u201c", '"').replace("\u201d", '"')
    s = _PUNCT.sub(" ", s)
    return _WS.sub(" ", s).strip()


def _coverage(needle: str, hay: str) -> float:
    """Share of `needle` characters that appear in `hay` as matching blocks."""
    if not needle:
        return 0.0
    sm = SequenceMatcher(None, hay, needle, autojunk=False)
    return sum(b.size for b in sm.get_matching_blocks()) / len(needle)


def quote_supported(quote: str, resume_text: str, threshold: float = 0.9) -> bool:
    """True if the quote is (almost) verbatim in the resume.

    Exact normalised substring first; otherwise fuzzy match against single lines and
    pairs of adjacent lines (PDF text often wraps). Quotes containing '...' are split and
    every fragment must be supported."""
    parts = [p for p in re.split(r"\.\.\.|\u2026", quote) if len(norm(p)) >= 3]
    if not parts:
        return False
    nr = norm(resume_text)
    lines = [norm(l) for l in resume_text.splitlines() if norm(l)]
    windows = lines + [lines[i] + " " + lines[i + 1] for i in range(len(lines) - 1)]
    for p in parts:
        nq = norm(p)
        if nq in nr:
            continue
        if len(nq) < 8:
            return False
        if not any(_coverage(nq, w) >= threshold for w in windows if abs(len(w) - len(nq)) < max(len(nq), 40) * 2):
            return False
    return True


def split_valid(items: list[str], allowed: set[str]) -> tuple[list[str], list[str]]:
    ok = [i for i in dict.fromkeys(items) if i in allowed]
    bad = [i for i in dict.fromkeys(items) if i not in allowed]
    return ok, bad

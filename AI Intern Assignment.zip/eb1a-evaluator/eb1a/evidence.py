"""Turn resume text into numbered 'evidence units' (one line / bullet each) and pick the
ones most relevant to a criterion. Numbering lets us show the model small, referenceable
pieces and lets us verify quotes against the original text afterwards."""
from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np

from .criteria import Criterion

_BULLET = re.compile(r"^\s*(?:[•\u2022\u25cf\u25aa\-\*–—>]+|\d+[.)])\s*")


@dataclass
class Unit:
    id: str
    text: str
    section: str = ""


def _is_heading(line: str, next_line: str | None) -> bool:
    words = line.split()
    if not words or len(words) > 6 or line.endswith((".", ";", ",")):
        return False
    # only ALL-CAPS lines, "Label:" lines or markdown '#' lines count as headings; title-case lines
    # ("Software Engineer") stay as evidence units because they carry job-title evidence.
    return line.isupper() or line.endswith(":") or line.startswith("#")


def split_units(text: str) -> list[Unit]:
    raw = [ln.rstrip() for ln in text.splitlines()]
    lines = [ln for ln in raw if ln.strip()]
    units: list[Unit] = []
    section = ""
    prev_open = False   # previous line was a wrapped fragment (PDF line wrapping)
    for i, ln in enumerate(lines):
        nxt = lines[i + 1] if i + 1 < len(lines) else None
        body = _BULLET.sub("", ln).strip()
        if not body:
            continue
        if _is_heading(body, nxt) and not _BULLET.match(ln):
            section = body.lstrip("# ").rstrip(":")
            prev_open = False
            continue
        is_wrapped = bool(units) and prev_open and not _BULLET.match(ln) and body[:1].islower()
        if is_wrapped:
            units[-1].text += " " + body
        else:
            units.append(Unit(f"L{len(units) + 1}", body, section))
        prev_open = not body.endswith((".", ";", ":", "!", "?"))
    return units


def _kw_hits(text: str, kws: tuple[str, ...]) -> int:
    low = text.lower()
    return sum(1 for k in kws if k in low)


def select_units(criterion: Criterion, units: list[Unit], embedder, max_units: int) -> list[Unit]:
    """If the resume is short, show everything. Otherwise rank lines by
    embedding similarity to the criterion + keyword hits, and keep the top N in original order."""
    if len(units) <= max_units:
        return units
    qv = embedder.encode([criterion.description], is_query=True)[0]
    uv = embedder.encode([u.text for u in units])
    sim = uv @ qv
    score = sim + 0.15 * np.array([min(_kw_hits(u.text, criterion.keywords), 3) for u in units])
    keep = set(np.argsort(-score)[:max_units].tolist())
    return [u for i, u in enumerate(units) if i in keep]


def build_query(criterion: Criterion, units: list[Unit], max_lines: int = 4) -> str:
    """Retrieval query = criterion text + the candidate lines that look most relevant."""
    ranked = sorted(units, key=lambda u: -_kw_hits(u.text, criterion.keywords))
    picked = [u.text for u in ranked[:max_lines] if _kw_hits(u.text, criterion.keywords) > 0]
    return criterion.query + (" || candidate evidence: " + " ; ".join(picked) if picked else "")

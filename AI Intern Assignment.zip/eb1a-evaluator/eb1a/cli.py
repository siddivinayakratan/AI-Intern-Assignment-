"""Command line interface.

  python -m eb1a.cli build-index --fetch          # download + index the real USCIS chapter
  python -m eb1a.cli build-index --html page.html # index a page you saved from your browser
  python -m eb1a.cli build-index --seed           # offline smoke-test corpus (NOT the real manual)
  python -m eb1a.cli inspect                      # print chunks + their criterion tags
  python -m eb1a.cli assess resume.pdf --out out.json
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter

from .config import INDEX_DIR, Settings
from .guardrails import InputError
from .index import build_index, load_retriever
from .ingest import build_chunks


def cmd_build(args) -> None:
    s = Settings()
    chunks = build_chunks(html_path=args.html, fetch=args.fetch, use_seed=args.seed)
    build_index(chunks, args.embedder or s.embedder, s.st_model)
    tags = Counter(c.criterion for c in chunks)
    print(f"Indexed {len(chunks)} chunks from '{chunks[0].source}' -> {INDEX_DIR}")
    print("Chunks per criterion tag:", dict(sorted(tags.items())))
    if chunks[0].source == "seed_fallback":
        print("WARNING: this is the small seed corpus, not the official manual. Use --fetch or --html for real results.")
    missing = [c for c in ["awards", "membership", "published_material", "judging", "original_contributions",
                           "scholarly_articles", "exhibitions", "leading_role", "high_salary", "commercial_success"] if tags[c] == 0]
    if missing:
        print(f"WARNING: no chunks tagged for: {missing}. Run `inspect` and adjust heading patterns in eb1a/criteria.py.")


def cmd_inspect(args) -> None:
    r = load_retriever()
    for c in r.chunks:
        print(f"[{c.id}] tag={c.criterion:<24} words={c.n_words:<4} {c.section}")
        if args.full:
            print("    " + c.text.replace("\n", "\n    ") + "\n")


def cmd_assess(args) -> None:
    from .pipeline import EB1AEvaluator

    s = Settings()
    if args.provider:
        s.provider = args.provider
    if args.model:
        s.model = args.model
    ev = EB1AEvaluator.from_settings(s)
    try:
        result = ev.assess_file(args.file)
    except InputError as e:
        print(f"Input problem: {e}", file=sys.stderr)
        sys.exit(2)
    if result.meta.corpus_source != "uscis_live":
        print("NOTE: index was built from the seed corpus, not the official USCIS manual.", file=sys.stderr)
    out = result.model_dump_json(indent=2)
    if args.out:
        open(args.out, "w", encoding="utf-8").write(out)
        print(f"Wrote {args.out}")
    if args.json or not args.out:
        print(out)
    else:
        _pretty(result)


def _pretty(r) -> None:
    print(f"\nEB-1A assessment: {r.candidate_label}")
    print("-" * 72)
    for c in r.criteria:
        print(f"{c.criterion_name:<62} {c.rating}")
    s = r.summary
    print("-" * 72)
    print(f"Strong: {s.strong_count}  Partial: {s.partial_count}  Meets 3-criteria minimum: {s.meets_minimum_three}")
    print(f"Readiness score: {s.readiness_score}/100  ({s.score_note})")
    print("\n" + s.narrative + "\n")
    if r.meta.guardrail_flags:
        print("Guardrail flags:", ", ".join(r.meta.guardrail_flags))


def main() -> None:
    p = argparse.ArgumentParser(prog="eb1a")
    sub = p.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build-index")
    b.add_argument("--fetch", action="store_true")
    b.add_argument("--html")
    b.add_argument("--seed", action="store_true")
    b.add_argument("--embedder", choices=["auto", "st", "tfidf"])
    b.set_defaults(fn=cmd_build)

    i = sub.add_parser("inspect")
    i.add_argument("--full", action="store_true")
    i.set_defaults(fn=cmd_inspect)

    a = sub.add_parser("assess")
    a.add_argument("file")
    a.add_argument("--out")
    a.add_argument("--json", action="store_true", help="print raw JSON")
    a.add_argument("--provider", choices=["anthropic", "openai", "rules"])
    a.add_argument("--model")
    a.set_defaults(fn=cmd_assess)

    args = p.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()

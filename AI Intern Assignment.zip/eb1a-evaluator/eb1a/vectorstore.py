"""A tiny vector index. Uses FAISS (IndexFlatIP, exact inner-product search) when it is
installed, otherwise a NumPy matrix multiply. They return identical results: with
normalised vectors, inner product == cosine similarity.

The corpus is ~100 chunks, so exact search is the right call: approximate indexes
(HNSW/IVF) would add recall risk for no speed benefit at this size.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

try:
    import faiss  # type: ignore
except Exception:  # pragma: no cover
    faiss = None


class VectorIndex:
    def __init__(self, matrix: np.ndarray):
        self.matrix = np.ascontiguousarray(matrix, dtype="float32")
        self.backend = "numpy"
        self._index = None
        if faiss is not None and len(self.matrix):
            self._index = faiss.IndexFlatIP(self.matrix.shape[1])
            self._index.add(self.matrix)
            self.backend = "faiss"

    def __len__(self) -> int:
        return len(self.matrix)

    def scores(self, qvec: np.ndarray) -> np.ndarray:
        """Similarity of one query vector against every chunk (index order)."""
        q = np.ascontiguousarray(qvec.reshape(1, -1), dtype="float32")
        if self._index is not None:
            sims, ids = self._index.search(q, len(self))
            out = np.zeros(len(self), dtype="float32")
            out[ids[0]] = sims[0]
            return out
        return (self.matrix @ q.T).ravel()

    def save(self, path: Path) -> None:
        np.save(path, self.matrix)

    @classmethod
    def load(cls, path: Path) -> "VectorIndex":
        return cls(np.load(path))

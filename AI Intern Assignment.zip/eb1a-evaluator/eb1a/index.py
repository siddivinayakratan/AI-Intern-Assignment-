"""Build / load the on-disk index: chunks.json + vectors.npy + embedder files."""
from __future__ import annotations

from pathlib import Path

from .config import INDEX_DIR
from .embeddings import load_embedder, make_embedder
from .ingest import Chunk, load_chunks, save_chunks
from .retriever import HybridRetriever
from .vectorstore import VectorIndex


def build_index(chunks: list[Chunk], embedder_kind: str = "auto", st_model: str = "BAAI/bge-small-en-v1.5",
                index_dir: Path = INDEX_DIR) -> HybridRetriever:
    index_dir.mkdir(parents=True, exist_ok=True)
    emb = make_embedder(embedder_kind, st_model)
    texts = [c.embed_text for c in chunks]
    emb.fit(texts)
    matrix = emb.encode(texts)
    vi = VectorIndex(matrix)
    save_chunks(chunks, index_dir / "chunks.json")
    vi.save(index_dir / "vectors.npy")
    emb.save(index_dir)
    return HybridRetriever(chunks, emb, vi)


def load_retriever(index_dir: Path = INDEX_DIR) -> HybridRetriever:
    if not (index_dir / "chunks.json").exists():
        raise FileNotFoundError("Index not found. Run: python -m eb1a.cli build-index --fetch   (or --seed for offline)")
    chunks = load_chunks(index_dir / "chunks.json")
    emb = load_embedder(index_dir)
    vi = VectorIndex.load(index_dir / "vectors.npy")
    return HybridRetriever(chunks, emb, vi)

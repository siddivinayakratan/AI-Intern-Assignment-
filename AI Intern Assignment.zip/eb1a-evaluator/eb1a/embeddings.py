"""Embedders. Both return L2-normalised float32 matrices, so cosine == dot product.

  st     - sentence-transformers (local, free). Default model: BAAI/bge-small-en-v1.5
  tfidf  - scikit-learn TF-IDF fitted on the policy chunks. Zero downloads; used as
           an offline fallback and in tests. It is lexical, so it can't match synonyms.
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np

BGE_QUERY_PREFIX = "Represent this sentence for searching relevant passages: "


def _normalize(m: np.ndarray) -> np.ndarray:
    m = np.asarray(m, dtype="float32")
    n = np.linalg.norm(m, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return m / n


class TfidfEmbedder:
    kind = "tfidf"

    def __init__(self):
        from sklearn.feature_extraction.text import TfidfVectorizer

        self.vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english", min_df=1)
        self.fitted = False

    @property
    def name(self) -> str:
        return "tfidf"

    def fit(self, texts: list[str]) -> "TfidfEmbedder":
        self.vec.fit(texts)
        self.fitted = True
        return self

    def encode(self, texts: list[str], is_query: bool = False) -> np.ndarray:
        return _normalize(self.vec.transform(texts).toarray())

    def save(self, d: Path) -> None:
        (d / "embedder.json").write_text(json.dumps({"kind": "tfidf"}))
        with open(d / "tfidf.pkl", "wb") as f:
            pickle.dump(self.vec, f)

    @classmethod
    def load(cls, d: Path) -> "TfidfEmbedder":
        e = cls()
        with open(d / "tfidf.pkl", "rb") as f:
            e.vec = pickle.load(f)
        e.fitted = True
        return e


class STEmbedder:
    kind = "st"

    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer

        self.model_name = model_name
        self.model = SentenceTransformer(model_name)

    @property
    def name(self) -> str:
        return f"st:{self.model_name}"

    def fit(self, texts):  # nothing to fit
        return self

    def encode(self, texts: list[str], is_query: bool = False) -> np.ndarray:
        if is_query and "bge" in self.model_name.lower():
            texts = [BGE_QUERY_PREFIX + t for t in texts]
        return _normalize(self.model.encode(texts, show_progress_bar=False))

    def save(self, d: Path) -> None:
        (d / "embedder.json").write_text(json.dumps({"kind": "st", "model": self.model_name}))

    @classmethod
    def load(cls, d: Path) -> "STEmbedder":
        meta = json.loads((d / "embedder.json").read_text())
        return cls(meta["model"])


def st_available() -> bool:
    try:
        import sentence_transformers  # noqa: F401
        return True
    except Exception:
        return False


def make_embedder(kind: str = "auto", st_model: str = "BAAI/bge-small-en-v1.5"):
    if kind == "auto":
        kind = "st" if st_available() else "tfidf"
    if kind == "st":
        return STEmbedder(st_model)
    if kind == "tfidf":
        return TfidfEmbedder()
    raise ValueError(f"unknown embedder: {kind}")


def load_embedder(d: Path):
    meta = json.loads((d / "embedder.json").read_text())
    return STEmbedder.load(d) if meta["kind"] == "st" else TfidfEmbedder.load(d)

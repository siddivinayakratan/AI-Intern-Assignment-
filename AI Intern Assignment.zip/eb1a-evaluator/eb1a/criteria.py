"""The 10 EB-1A criteria (8 CFR 204.5(h)(3)(i)-(x)) and how we map text to them.

Each criterion carries:
  description  - plain-language version of the regulation, shown to the LLM
  query        - retrieval query used against the policy manual
  headings     - regexes matched against section headings to tag chunks
  keywords     - lexical cues used to (a) tag untitled chunks, (b) pick resume lines
"""
from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Criterion:
    id: str
    name: str
    reg: str
    description: str
    query: str
    headings: tuple[str, ...]
    keywords: tuple[str, ...]
    default_next_step: str


CRITERIA: list[Criterion] = [
    Criterion(
        "awards", "Awards and prizes", "204.5(h)(3)(i)",
        "Receipt of lesser nationally or internationally recognized prizes or awards for excellence in the field of endeavor.",
        "lesser nationally or internationally recognized prizes or awards for excellence in the field; selection criteria, number of recipients, national or international recognition",
        (r"\bawards?\b", r"\bprizes?\b"),
        ("award", "prize", "medal", "winner", "best paper", "fellowship", "honor", "finalist", "grant"),
        "Collect documentation of each award: who granted it, the selection criteria, number of applicants vs. recipients, and press coverage of the award.",
    ),
    Criterion(
        "membership", "Membership in associations requiring outstanding achievement", "204.5(h)(3)(ii)",
        "Membership in associations in the field that require outstanding achievements of their members, as judged by recognized national or international experts.",
        "membership in associations in the field which require outstanding achievements of their members judged by recognized national or international experts; bylaws, admission requirements",
        (r"\bmembership\b", r"\bassociations?\b"),
        ("member", "fellow", "senior member", "elected", "invitation", "academy", "society", "association"),
        "Obtain the association's bylaws or admission criteria showing that membership requires outstanding achievement judged by experts, not just dues or employment.",
    ),
    Criterion(
        "published_material", "Published material about the candidate", "204.5(h)(3)(iii)",
        "Published material about the person in professional or major trade publications or other major media, relating to their work in the field.",
        "published material about the alien in professional or major trade publications or other major media, title, date, author, circulation, relating to the alien's work",
        (r"published material", r"major media", r"\bmedia\b"),
        ("featured", "profiled", "interview", "coverage", "press", "magazine", "newspaper", "article about", "reported", "cited in"),
        "Gather the actual articles (title, date, author, circulation/readership data) that are ABOUT you and your work, with certified translations if needed.",
    ),
    Criterion(
        "judging", "Judging the work of others", "204.5(h)(3)(iv)",
        "Evidence of participation, individually or on a panel, as a judge of the work of others in the same or an allied field.",
        "participation as a judge of the work of others in the same or an allied field of specialization, individually or on a panel, peer review",
        (r"\bjudg", r"\bpeer review"),
        ("reviewer", "peer review", "program committee", "judge", "jury", "panel", "referee", "editorial board", "area chair", "juror"),
        "Request confirmation letters from editors or organizers stating the dates, your role, and the number of submissions you evaluated.",
    ),
    Criterion(
        "original_contributions", "Original contributions of major significance", "204.5(h)(3)(v)",
        "Evidence of original scientific, scholarly, artistic, athletic, or business-related contributions of major significance in the field.",
        "original scientific scholarly artistic athletic or business-related contributions of major significance in the field; evidence of impact, adoption, citations, expert letters",
        (r"original (scientific|contributions)", r"major significance", r"contributions"),
        ("pioneer", "novel", "invented", "patent", "first to", "introduced", "adopted", "state-of-the-art", "open-source", "citations", "licensed", "breakthrough"),
        "Document the real-world impact of your work with adoption data, citation counts, licensing deals, and independent expert letters explaining why it is significant.",
    ),
    Criterion(
        "scholarly_articles", "Authorship of scholarly articles", "204.5(h)(3)(vi)",
        "Authorship of scholarly articles in the field, in professional or major trade publications or other major media.",
        "authorship of scholarly articles in the field in professional or major trade publications or other major media; peer-reviewed journals, citations",
        (r"scholarly articles?", r"authorship"),
        ("published in", "journal", "proceedings", "arxiv", "doi", "et al", "co-author", "first author", "publications", "peer-reviewed", "conference paper"),
        "Compile a publication list with venue, date, your author position, and citation counts; flag the peer-reviewed venues with strongest reputations.",
    ),
    Criterion(
        "exhibitions", "Display of work at artistic exhibitions", "204.5(h)(3)(vii)",
        "Evidence that the person's work has been displayed at artistic exhibitions or showcases.",
        "display of the alien's work in the field at artistic exhibitions or showcases; visual arts, venue reputation",
        (r"exhibitions?", r"showcases?", r"\bdisplay\b"),
        ("exhibit", "exhibition", "gallery", "solo show", "group show", "museum", "biennale", "showcase", "installation"),
        "If you work in an artistic field, gather exhibition catalogs, venue information, and dates; otherwise this criterion is likely not applicable.",
    ),
    Criterion(
        "leading_role", "Leading or critical role for distinguished organizations", "204.5(h)(3)(viii)",
        "Evidence that the person has performed in a leading or critical role for organizations or establishments that have a distinguished reputation.",
        "performed in a leading or critical role for organizations or establishments that have a distinguished reputation; organizational charts, position in hierarchy, reputation of the organization",
        (r"leading or critical", r"critical role", r"distinguished reputation"),
        ("founder", "co-founder", "ceo", "cto", "chief", "director", "head of", "vice president", "vp", "principal", "lead", "managed"),
        "Obtain an org chart and letters from senior leadership showing your position, plus evidence of the organization's distinguished reputation (press, rankings, funding).",
    ),
    Criterion(
        "high_salary", "High salary or remuneration", "204.5(h)(3)(ix)",
        "Evidence that the person has commanded a high salary or other significantly high remuneration for services, in relation to others in the field.",
        "commanded a high salary or other significantly high remuneration for services in relation to others in the field; comparative wage data, same geographic area",
        (r"salary", r"remuneration"),
        ("salary", "compensation", "earned", "$", "equity", "bonus", "ctc", "lpa", "annual"),
        "Assemble pay stubs or contracts plus comparative wage data (surveys, BLS/industry data) for your occupation and region showing you are at the top of the range.",
    ),
    Criterion(
        "commercial_success", "Commercial success in the performing arts", "204.5(h)(3)(x)",
        "Evidence of commercial successes in the performing arts, as shown by box office receipts or record, cassette, compact disk, or video sales.",
        "commercial successes in the performing arts as shown by box office receipts or record, cassette, compact disk, or video sales",
        (r"commercial success", r"performing arts"),
        ("box office", "sales", "album", "streams", "platinum", "gold record", "sold-out", "sold out", "tour", "chart", "ticket"),
        "If you are a performing artist, collect certified sales, streaming, or box-office statements; otherwise this criterion is likely not applicable.",
    ),
]

CRITERIA_BY_ID = {c.id: c for c in CRITERIA}
GENERAL = "general"

# Headings that look like criterion names but are about the one-time-achievement path or the
# overall framework, so the chunk should be shared by all criteria.
_GENERAL_HEADING = re.compile(
    r"one[- ]time|nobel|final merits|sustained|comparable evidence|two[- ]part|initial evidence|overview|purpose|background",
    re.I,
)


def tag_chunk(heading_path: list[str], text: str) -> str:
    """Return a criterion id or 'general'.

    1. Walk headings from deepest to shallowest; first match wins
       (framework-level headings are checked first so they stay shared).
    2. If no heading matches, fall back to key-phrase counting in the body text.
    """
    for h in reversed(heading_path):
        if _GENERAL_HEADING.search(h):
            return GENERAL
        for c in CRITERIA:
            if any(re.search(p, h, re.I) for p in c.headings):
                return c.id
    low = text.lower()
    scores = {}
    for c in CRITERIA:
        phrases = [c.name.lower(), c.description.lower()[:40]]
        scores[c.id] = sum(low.count(p) for p in phrases) + sum(low.count(k) for k in c.keywords[:3])
    best = max(scores, key=scores.get)
    if scores[best] >= 3 and list(scores.values()).count(scores[best]) == 1:
        return best
    return GENERAL

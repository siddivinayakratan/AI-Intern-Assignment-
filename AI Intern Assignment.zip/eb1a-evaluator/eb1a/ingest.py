"""Fetch -> clean -> section -> chunk the USCIS Policy Manual chapter.

Chunking strategy (and why):
  * The manual is organised by headings, one block per criterion. We keep that
    structure: each chunk lives inside exactly one leaf section, so a chunk never
    mixes advice about two different criteria.
  * Every chunk is prefixed with its heading path ("... > Awards and prizes") when
    embedded. A paragraph like "The number of recipients matters" is meaningless
    without knowing which criterion it belongs to.
  * Target size ~250 words, hard cap 320, with a one-paragraph overlap. Small enough
    that a retrieved chunk is about one idea, large enough to keep an officer's
    full reasoning together.
  * Tiny leaf sections are merged into the previous chunk of the same parent.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .config import RAW_DIR, SEED_PATH, SOURCE_URL
from .criteria import tag_chunk

MAX_WORDS = 250
HARD_CAP = 320
MIN_WORDS = 50
OVERLAP_MAX_WORDS = 60


@dataclass
class Section:
    heading_path: list[str]
    paragraphs: list[str] = field(default_factory=list)


@dataclass
class Chunk:
    id: str
    text: str
    heading_path: list[str]
    section: str
    criterion: str
    source: str          # 'uscis_live' | 'seed_fallback'
    source_url: str
    n_words: int

    @property
    def embed_text(self) -> str:
        return f"{self.section}\n{self.text}"


# ----------------------------------------------------------------------------- fetch

def fetch_html(url: str = SOURCE_URL, cache: bool = True) -> str:
    import requests

    RAW_DIR.mkdir(parents=True, exist_ok=True)
    cache_path = RAW_DIR / "policy_manual_v6_f_ch2.html"
    if cache and cache_path.exists():
        return cache_path.read_text(encoding="utf-8")
    resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (eb1a-evaluator research project)"}, timeout=30)
    resp.raise_for_status()
    cache_path.write_text(resp.text, encoding="utf-8")
    return resp.text


# ----------------------------------------------------------------------------- clean + parse

_FOOTNOTE_MARK = re.compile(r"\[\s*footnote\s*\d+\s*\]", re.I)
_WS = re.compile(r"[ \t\u00a0]+")


def clean_text(s: str) -> str:
    s = _FOOTNOTE_MARK.sub("", s)
    s = s.replace("\u2019", "'").replace("\u201c", '"').replace("\u201d", '"')
    s = _WS.sub(" ", s)
    return re.sub(r"\s*\n\s*", " ", s).strip()


def _own_text(el) -> str:
    """Text of a <li>/<p> without the text of nested lists (avoids duplicates)."""
    clone = copy.copy(el)
    for nested in clone.find_all(["ul", "ol"]):
        nested.decompose()
    return clean_text(clone.get_text(" "))


def _is_link_list(el) -> bool:
    items = el.find_all("li", recursive=False)
    if not items:
        return False
    only_links = sum(1 for li in items if li.find("a") and len(li.get_text(strip=True).split()) < 14)
    return only_links == len(items)


def html_to_sections(html: str, skip_footnotes: bool = True) -> list[Section]:
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "nav", "header", "footer", "aside", "form", "noscript"]):
        tag.decompose()
    root = soup.find("main") or soup.body or soup
    for lst in root.find_all(["ul", "ol"]):       # drop sidebar/TOC style link lists
        if _is_link_list(lst):
            lst.decompose()

    sections: list[Section] = []
    stack: list[tuple[int, str]] = []
    current = Section([])
    sections.append(current)

    for el in root.find_all(["h1", "h2", "h3", "h4", "h5", "p", "li", "table"]):
        name = el.name
        if name[0] == "h" and name[1:].isdigit():
            level = int(name[1])
            title = clean_text(el.get_text(" "))
            if not title:
                continue
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, title))
            current = Section([t for _, t in stack])
            sections.append(current)
        elif name == "table":
            rows = []
            for tr in el.find_all("tr"):
                cells = [clean_text(c.get_text(" ")) for c in tr.find_all(["th", "td"])]
                if any(cells):
                    rows.append(" | ".join(cells))
            if rows:
                current.paragraphs.append("\n".join(rows))
        else:
            if el.find_parent("table"):
                continue
            txt = _own_text(el)
            if len(txt.split()) >= 4:
                current.paragraphs.append(txt)

    out = []
    for s in sections:
        if not s.paragraphs:
            continue
        if skip_footnotes and s.heading_path and re.search(r"footnote", s.heading_path[-1], re.I):
            continue
        out.append(s)
    return out


def markdown_to_sections(md: str) -> list[Section]:
    sections: list[Section] = []
    stack: list[tuple[int, str]] = []
    current = Section([])
    sections.append(current)
    buf: list[str] = []

    def flush():
        if buf:
            current.paragraphs.append(clean_text(" ".join(buf)))
            buf.clear()

    for line in md.splitlines():
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush()
            level, title = len(m.group(1)), m.group(2).strip()
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, title))
            current = Section([t for _, t in stack])
            sections.append(current)
        elif not line.strip():
            flush()
        else:
            buf.append(line.strip())
    flush()
    # The seed file's H1 is a disclaimer banner: drop its own text and keep it out of every heading path.
    out = []
    for sec in sections:
        if sec.heading_path and sec.heading_path[0].startswith("SEED CORPUS"):
            sec.heading_path = sec.heading_path[1:]
        if sec.heading_path and sec.paragraphs:
            out.append(sec)
    return out


# ----------------------------------------------------------------------------- chunking

def _split_long(par: str, cap: int) -> list[str]:
    if len(par.split()) <= cap:
        return [par]
    sents = re.split(r"(?<=[.!?])\s+", par)
    out, cur = [], []
    for s in sents:
        if sum(len(x.split()) for x in cur) + len(s.split()) > cap and cur:
            out.append(" ".join(cur))
            cur = []
        cur.append(s)
    if cur:
        out.append(" ".join(cur))
    return out


def chunk_sections(sections: list[Section], source: str, source_url: str = SOURCE_URL) -> list[Chunk]:
    raw: list[tuple[list[str], list[str]]] = []   # (heading_path, paragraphs)
    for sec in sections:
        pars = [p for par in sec.paragraphs for p in _split_long(par, HARD_CAP)]
        cur: list[str] = []
        for p in pars:
            if cur and sum(len(x.split()) for x in cur) + len(p.split()) > MAX_WORDS:
                raw.append((sec.heading_path, cur))
                last = cur[-1]
                cur = [last] if len(last.split()) <= OVERLAP_MAX_WORDS else []
            cur.append(p)
        if cur:
            raw.append((sec.heading_path, cur))

    # Merge tiny chunks into the previous chunk, but ONLY when both carry the same criterion tag
    # (or are both 'general'). Merging across tags would blur two criteria into one chunk and
    # silently delete the guidance for the smaller one.
    merged: list[tuple[list[str], list[str]]] = []
    for path, pars in raw:
        words = sum(len(p.split()) for p in pars)
        same_tag = bool(merged) and tag_chunk(merged[-1][0], "\n".join(merged[-1][1])) == tag_chunk(path, "\n".join(pars))
        if merged and words < MIN_WORDS and merged[-1][0][:1] == path[:1] and same_tag:
            merged[-1] = (merged[-1][0], merged[-1][1] + pars)
        else:
            merged.append((path, pars))

    chunks: list[Chunk] = []
    for i, (path, pars) in enumerate(merged):
        text = "\n".join(pars)
        section = " > ".join(path) if path else "Document"
        chunks.append(Chunk(
            id=f"c{i:03d}", text=text, heading_path=path, section=section,
            criterion=tag_chunk(path, text), source=source, source_url=source_url,
            n_words=len(text.split()),
        ))
    return chunks


# ----------------------------------------------------------------------------- entry points

def build_chunks(html_path: str | None = None, fetch: bool = False, use_seed: bool = False) -> list[Chunk]:
    if use_seed:
        sections = markdown_to_sections(Path(SEED_PATH).read_text(encoding="utf-8"))
        return chunk_sections(sections, "seed_fallback")
    if html_path:
        html = Path(html_path).read_text(encoding="utf-8")
    elif fetch:
        html = fetch_html()
    else:
        cached = RAW_DIR / "policy_manual_v6_f_ch2.html"
        if not cached.exists():
            raise FileNotFoundError("No cached USCIS page. Use --fetch, --html <file>, or --seed.")
        html = cached.read_text(encoding="utf-8")
    sections = html_to_sections(html)
    if not sections:
        raise ValueError("Parsed zero sections from the HTML. Save the page from your browser and pass --html.")
    return chunk_sections(sections, "uscis_live")


def save_chunks(chunks: list[Chunk], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps([asdict(c) for c in chunks], indent=2), encoding="utf-8")


def load_chunks(path: Path) -> list[Chunk]:
    return [Chunk(**d) for d in json.loads(path.read_text(encoding="utf-8"))]


def corpus_hash(chunks: list[Chunk]) -> str:
    return hashlib.sha256("".join(c.text for c in chunks).encode()).hexdigest()[:12]

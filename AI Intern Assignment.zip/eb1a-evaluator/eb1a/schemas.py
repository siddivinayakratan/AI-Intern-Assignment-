"""Pydantic schemas. Two layers on purpose:

RawCriterionOutput  - what we ask the LLM for (small, easy to get right)
ProfileAssessment   - the final, verified, user-facing JSON
"""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

Rating = Literal["Strong", "Partial", "Missing", "Insufficient Info"]
RATINGS: tuple[str, ...] = ("Strong", "Partial", "Missing", "Insufficient Info")


class RawCriterionOutput(BaseModel):
    """Exactly what the model must return for one criterion."""

    rating: Rating
    evidence: list[str] = Field(default_factory=list)      # verbatim resume quotes
    reasoning: str = Field(min_length=10)
    citations: list[str] = Field(default_factory=list)     # chunk ids from the supplied guidance
    next_steps: list[str] = Field(default_factory=list)

    @field_validator("evidence", "citations", "next_steps")
    @classmethod
    def _strip_empty(cls, v: list[str]) -> list[str]:
        return [s.strip() for s in v if isinstance(s, str) and s.strip()]


class Diagnostics(BaseModel):
    """Per-criterion QA numbers. Used by the eval, also useful to a human reviewer."""

    attempts: int = 1
    raw_quote_count: int = 0           # quotes the model produced on its first attempt
    raw_unverified_quotes: int = 0     # of those, how many were NOT found in the resume
    raw_citation_count: int = 0
    raw_invalid_citations: int = 0     # cited ids that were not in the retrieved set
    downgraded: bool = False           # Strong/Partial -> Insufficient Info for lack of verified evidence
    citation_fallback: bool = False    # we had to attach the top retrieved chunk ourselves
    next_steps_fallback: bool = False
    retrieved_ids: list[str] = Field(default_factory=list)


class Citation(BaseModel):
    chunk_id: str
    section: str
    snippet: str          # first ~300 chars of the chunk, so a reader can sanity check quickly


class CriterionAssessment(BaseModel):
    criterion_id: str
    criterion_name: str
    regulation: str
    rating: Rating
    evidence: list[str] = Field(default_factory=list)
    reasoning: str
    citations: list[Citation] = Field(default_factory=list)
    next_steps: list[str] = Field(min_length=1, max_length=2)
    diagnostics: Optional[Diagnostics] = None

    @model_validator(mode="after")
    def _consistency(self) -> "CriterionAssessment":
        if self.rating in ("Strong", "Partial") and not self.evidence:
            raise ValueError(f"{self.criterion_id}: rating {self.rating} requires at least one evidence quote")
        if not self.citations:
            raise ValueError(f"{self.criterion_id}: at least one citation is required")
        return self


class OverallSummary(BaseModel):
    strongest_criteria: list[str]
    main_gaps: list[str]
    strong_count: int = Field(ge=0, le=10)
    partial_count: int = Field(ge=0, le=10)
    meets_minimum_three: bool
    readiness_score: int = Field(ge=0, le=100)
    score_note: str
    narrative: str
    disclaimer: str = (
        "Automated, educational assessment based on public USCIS guidance. "
        "It is not legal advice and does not predict the outcome of a petition."
    )


class RunMeta(BaseModel):
    provider: str
    model: str
    embedder: str
    corpus_source: str                 # 'uscis_live' | 'seed_fallback'
    top_k: int
    input_tokens: int = 0
    output_tokens: int = 0
    llm_calls: int = 0
    latency_s: float = 0.0
    guardrail_flags: list[str] = Field(default_factory=list)


class ProfileAssessment(BaseModel):
    candidate_label: str
    criteria: list[CriterionAssessment]
    summary: OverallSummary
    meta: RunMeta

    @model_validator(mode="after")
    def _ten_unique(self) -> "ProfileAssessment":
        ids = [c.criterion_id for c in self.criteria]
        if len(ids) != 10 or len(set(ids)) != 10:
            raise ValueError("assessment must contain exactly the 10 EB-1A criteria, once each")
        return self

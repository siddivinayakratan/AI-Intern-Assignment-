"""Input handling: PDF/text extraction, garbled/empty input checks, prompt-injection screening.

Design stance: a resume is UNTRUSTED DATA. We (1) quarantine lines that read like instructions
to an AI so they never reach the model as 'evidence', (2) tell the model in the system prompt
that resume text is data, and (3) verify every quote and citation after the fact.
Quarantine is regex-based, so it is a first line of defence, not a guarantee. See README.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


class InputError(ValueError):
    """Raised for input we should refuse to evaluate (empty, unreadable, garbled)."""


INJECTION_PATTERNS = [
    r"ignore (all |any )?(the )?(previous|prior|above|earlier) (instructions|prompts?|rules)",
    r"disregard (all |any )?(the )?(previous|prior|above|earlier)",
    r"(system|assistant|developer)\s*(prompt|note|message|instruction)",
    r"you are (now|an?) (an? )?(ai|assistant|evaluator|grader|model)",
    r"\b(evaluator|grader|reviewer|ai|llm|model)\b.{0,40}\b(must|should|shall|please)\b.{0,40}\b(rate|score|grade|mark|output|respond)",
    r"\brate (every|all|each)\b",
    r"(output|respond with|return)\s+(only\s+)?(\"|')?(strong|json)",
    r"<\s*/?\s*(system|assistant|instructions?)\s*>",
    r"\[\s*(system|inst)\s*\]",
    r"do not (mention|reveal|follow)",
    r"\(\s*(verified|confirmed|pre-?approved|authenticated)\s*\)",   # self-asserted "verification" tags
]
_INJ = re.compile("|".join(f"(?:{p})" for p in INJECTION_PATTERNS), re.I)


@dataclass
class CleanedInput:
    text: str
    flags: list[str] = field(default_factory=list)
    quarantined: list[str] = field(default_factory=list)


def extract_text(path: str | Path | None = None, data: bytes | None = None, filename: str = "") -> str:
    name = (filename or (str(path) if path else "")).lower()
    if data is None and path is not None:
        data = Path(path).read_bytes()
    if data is None:
        raise InputError("No input provided.")
    if name.endswith(".pdf") or data[:4] == b"%PDF":
        return _pdf_text(data)
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    raise InputError("Could not decode the file as text.")


def _pdf_text(data: bytes) -> str:
    import io

    try:
        import pdfplumber

        with pdfplumber.open(io.BytesIO(data)) as pdf:
            pages = [(p.extract_text() or "") for p in pdf.pages]
        text = "\n".join(pages)
    except Exception as e:  # corrupt / encrypted
        raise InputError(f"Could not read PDF: {e}") from e
    if len(text.strip()) < 40:
        raise InputError("The PDF has no extractable text (scanned image?). Please upload a text PDF or paste the text.")
    return text


def _garbled_ratio(text: str) -> float:
    if not text:
        return 1.0
    bad = sum(1 for ch in text if ch == "\ufffd" or (not ch.isalnum() and not ch.isspace() and ch not in ".,;:()[]{}'\"-–—/&%$@#+*•·|!?_=<>€£₹"))
    return bad / len(text)


def clean_input(text: str, max_chars: int = 30000) -> CleanedInput:
    flags: list[str] = []
    text = text.replace("\x00", "").replace("\r\n", "\n").replace("\r", "\n")
    # strip zero-width / bidi control characters sometimes used to hide text
    stripped = re.sub(r"[\u200b-\u200f\u202a-\u202e\u2060\ufeff]", "", text)
    if stripped != text:
        flags.append("removed_invisible_characters")
        text = stripped

    words = text.split()
    if len(words) < 25:
        raise InputError("The profile is too short to evaluate (fewer than 25 words). Please provide a fuller resume.")
    if _garbled_ratio(text) > 0.25:
        raise InputError("The text looks garbled (too many unreadable characters). Please re-export the PDF or paste plain text.")
    if len(text) > max_chars:
        text = text[:max_chars]
        flags.append(f"truncated_to_{max_chars}_chars")

    kept, quarantined = [], []
    for ln in text.splitlines():
        if _INJ.search(ln):
            quarantined.append(ln.strip())
        else:
            kept.append(ln)
    if quarantined:
        flags.append(f"possible_prompt_injection_quarantined_{len(quarantined)}_lines")
    return CleanedInput("\n".join(kept), flags, quarantined)

"""Thin LLM wrappers. Each returns text + token usage + latency. Nothing else is hidden
behind them, so the prompts and parsing stay visible in evaluator.py."""
from __future__ import annotations

import json
import re
import threading
import time
from dataclasses import dataclass

from .config import DEFAULT_MODELS


@dataclass
class LLMResult:
    text: str
    input_tokens: int = 0
    output_tokens: int = 0
    latency_s: float = 0.0


class UsageTracker:
    def __init__(self):
        self._lock = threading.Lock()
        self.calls = self.input_tokens = self.output_tokens = 0
        self.latency_s = 0.0

    def add(self, r: LLMResult) -> None:
        with self._lock:
            self.calls += 1
            self.input_tokens += r.input_tokens
            self.output_tokens += r.output_tokens
            self.latency_s += r.latency_s


def _with_retries(fn, attempts: int = 4):
    delay = 2.0
    for i in range(attempts):
        try:
            return fn()
        except Exception as e:  # rate limits / transient network errors
            msg = str(e).lower()
            transient = any(k in msg for k in ("rate", "429", "overloaded", "timeout", "temporarily", "503", "529"))
            if i == attempts - 1 or not transient:
                raise
            time.sleep(delay)
            delay *= 2


class AnthropicLLM:
    def __init__(self, model: str):
        import anthropic  # imported lazily so other providers don't need it

        self.client = anthropic.Anthropic()   # reads ANTHROPIC_API_KEY
        self.model = model

    def complete(self, system: str, user: str, max_tokens: int = 1200) -> LLMResult:
        t0 = time.time()
        resp = _with_retries(lambda: self.client.messages.create(
            model=self.model, max_tokens=max_tokens, temperature=0,
            system=system, messages=[{"role": "user", "content": user}],
        ))
        text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        return LLMResult(text, resp.usage.input_tokens, resp.usage.output_tokens, time.time() - t0)


class OpenAILLM:
    def __init__(self, model: str):
        from openai import OpenAI

        self.client = OpenAI()               # reads OPENAI_API_KEY
        self.model = model

    def complete(self, system: str, user: str, max_tokens: int = 1200) -> LLMResult:
        t0 = time.time()
        resp = _with_retries(lambda: self.client.chat.completions.create(
            model=self.model, temperature=0, max_tokens=max_tokens,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        ))
        u = resp.usage
        return LLMResult(resp.choices[0].message.content or "", u.prompt_tokens, u.completion_tokens, time.time() - t0)


def make_llm(provider: str, model: str = ""):
    model = model or DEFAULT_MODELS.get(provider, "")
    if provider == "anthropic":
        return AnthropicLLM(model)
    if provider == "openai":
        return OpenAILLM(model)
    raise ValueError(f"unknown LLM provider: {provider}")


def parse_json(text: str) -> dict:
    """Pull the first JSON object out of a model reply, tolerating ```json fences and chatter."""
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t, flags=re.I)
    start, end = t.find("{"), t.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError("no JSON object found in model output")
    return json.loads(t[start:end + 1])

# Prep for the follow-up call (read this, and be able to say it in your own words)

**Why chunk by heading?** The manual is organised per criterion; keeping a chunk inside one section stops two criteria blurring together,
and prefixing the heading path gives each chunk the context an isolated paragraph lacks.

**Why ~250 words and a one-paragraph overlap?** Small enough that one chunk is about one idea, large enough to keep an officer's reasoning intact.
Overlap protects sentences that straddle a boundary. I did not tune this on the real corpus, so say so and say how you would (retrieval ablation).

**Why hybrid (BM25 + dense)?** Legal text has exact terms ("peer review", "lesser nationally or internationally recognized") where BM25 is strong,
and paraphrases where embeddings help. RRF combines ranks without calibrating scores. Be ready to say what happens with the TF-IDF fallback
(both signals are lexical, so hybrid adds little).

**Why scope retrieval by criterion?** Structure is a strong prior. Risk: wrong tags hide relevant text. Mitigation: general chunks, `inspect`, a test.

**Why one call per criterion?** Focused context, parallel, isolated failures, per-criterion retrieval. Trade-off: more calls.

**What stops hallucination?** Prompt rules *and* code: fuzzy-match every quote to the resume, check ids against the retrieved set, one repair attempt, auto-downgrade.
The eval measures the raw first-attempt rate, so it shows the model's behaviour, not just the safety net's.

**Is the readiness score meaningful?** It is a heuristic with chosen weights, not a probability of approval. Say that before they ask.

**Biggest weaknesses?** Small self-labelled eval; chunk-level (not sentence-level) citation checking; regex injection screening; no final-merits modelling;
parser for the live page was written without being able to test it against the real HTML in my build environment (say what you did when you ran it).

**Things only you can fill in:** your LLM results, which cells surprised you, and whether any label turned out to be wrong.

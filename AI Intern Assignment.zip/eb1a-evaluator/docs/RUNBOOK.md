# Runbook: finish and submit (about 45-60 minutes)

These steps need internet and an API key, so they could not be done in the build sandbox.

## 1. Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env     # add ANTHROPIC_API_KEY (or OPENAI_API_KEY). Never commit .env
python -m unittest discover -s tests -v     # all tests should pass with real pydantic
```
If a test fails, fix it before anything else and note what it was.

## 2. Build the real knowledge base
```bash
python -m eb1a.cli build-index --fetch      # or: --html page.html (saved from browser)
python -m eb1a.cli inspect                  # every criterion must own >=1 chunk; meta.corpus_source must be uscis_live
```
If a criterion has no chunks, the HTML parser needs adjusting (eb1a/ingest.py, html_to_sections).

## 3. Try it
```bash
python -m eb1a.cli assess data/profiles/p03_startup_founder.txt
streamlit run app.py
```

## 4. Run the evals
```bash
python -m eval.run_eval --runs rules,anthropic --judge --tag llm
python -m eval.retrieval_eval --k 5
```
Open `eval/results/eval_llm.md`.

## 5. Fill in docs/FAILURE_ANALYSIS.md Part B
Use your own numbers only. Read at least 10 mistakes and 10 judged-unsupported citations yourself.
Fix any label in data/labels.json that you decide was wrong, say so, and re-run.

## 6. Update README
Replace the "LLM (fill in)" column with your results. Update the "Status" table to say what you actually ran.

## 7. Push to GitHub
```bash
git init && git add . && git commit -m "EB-1A evaluator"
git status    # confirm .env is NOT listed
```
Optional: record a 3-5 minute Loom (architecture, one live run, the eval table, one failure you found).

## 8. Before the call
Read docs/DEFEND_YOUR_CHOICES.md and be able to answer each point in your own words.

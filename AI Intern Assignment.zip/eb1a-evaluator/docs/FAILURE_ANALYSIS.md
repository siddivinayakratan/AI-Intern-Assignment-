# Failure analysis

Two parts. **Part A is real**: I ran the rule-based baseline on the 7 test profiles (21 mistakes out of 70 cells).
**Part B is a template you must fill** after running the LLM evaluator with your own API key. I could not call an
LLM while building this, so I have not written any LLM numbers or claimed any LLM behaviour here.

> Caveat on everything below: the test profiles and the labels were written by the same person, the set is small
> (70 cells, 7 synthetic profiles), and the numbers in Part A were produced with the offline *seed* corpus, not the
> official manual. Treat them as a smoke test of the harness plus a baseline, not as a benchmark.

---

## Part A. Rule-based baseline (measured)

Overall: 70.0% exact rating accuracy (majority-class guess = 42.9%), 85.7% Strong-vs-not, 0% hallucinated evidence
(by construction: it only returns verbatim lines).

Mistake patterns, with the cells that show each one:

1. **Scope blindness (over-rating).** It sees the word "national" or "director" and says Strong.
   `p02 awards` (national hackathon *finalist* -> Strong, expected Partial), `p04 awards` (finalist of a national prize),
   `p03 membership` ("invitation-only" -> Strong, expected Insufficient Info), `p04/p05 leading_role`
   (founder of a small residency / festival director -> Strong, expected Partial).
   *Why:* keyword rules can't tell that a finalist is weaker than a winner or that "invitation-only" says nothing about
   whether achievement is required. This is the exact distinction the USCIS guidance cares about.
2. **Counting instead of reading (under-rating).** `published_material` is rated by number of matching lines, so a
   single line naming two major outlets (`p01`, `p03`, `p04`, `p05`) is Partial instead of Strong.
3. **Vocabulary gaps.** `original_contributions` for the artist and musician (no words like "patent" or "novel";
   they say "developed a technique ... now taught in 3 programs", "pioneering a style") -> Missing, expected Partial.
4. **Can't express "mentioned but unclear".** All four `Insufficient Info` cells in `p06` (vague resume) became Missing
   because vague language contains no keywords. Insufficient Info recall is 27%, the worst class. This is the case where
   an LLM should help most.
5. **Qualifier blindness.** "Student Member, IEEE" and "Member, Musicians' Union (open membership)" -> Insufficient Info
   instead of Missing; the qualifiers that disqualify them are ignored.

What this tells us about the LLM version: the hard cells are not "find the keyword", they are *"weigh scope, selectivity
and impact against the guidance"*. That is why retrieval of the right guidance passage and a rubric in the prompt matter.

Bugs found while building (and fixed), worth mentioning because they show why I inspect before trusting numbers:
* The chunk-merging step merged a short "Commercial success" section into "High salary", leaving one criterion with no
  guidance at all. Fixed: merge only chunks with the same criterion tag. A test now asserts every criterion has its own chunk.
* A salary regex without word boundaries matched "earn" inside "Learning", giving a researcher a false salary signal.
* The injection regex caught the instruction line in `p07` but not the fake "Turing Award (verified)" line beside it; added a
  pattern for self-asserted "(verified)" tags. This is a heuristic and will miss other phrasings (see README, Guardrails).

---

## Part B. LLM evaluator (TO FILL after you run it)

Run: `python -m eval.run_eval --runs rules,anthropic --judge --tag llm`, then read `eval/results/eval_llm.md`.

Fill in honestly, with cell references (`profile / criterion: expected X, got Y`) and one sentence on *why*:

| Question | Your finding |
|---|---|
| Overall exact accuracy vs the baseline's 70.0%? | |
| Which rating class is worst (P/R)? Is Insufficient Info still the weak class? | |
| Over-rating or under-rating? (Look at the confusion matrix: is the model optimistic?) | |
| Hallucinated evidence rate (raw, before the verifier)? Which quotes, and what kind (paraphrase vs invented)? | |
| Invalid citation rate? Did the repair retry fix them? How many `citation_fallback` / `downgraded`? | |
| Citation support by the LLM judge. Read 10 judged-unsupported citations yourself: is the judge right? | |
| `p07` injection: resisted? If not, which line leaked and why did the guard miss it? | |
| `p05 exhibitions` (contestable label): what did the model say, and do you agree with your own label? | |
| `p04 commercial_success` (art sales are not performing arts): did it fall for the trap? | |
| Latency, tokens, and cost per profile | |

Failure categories to check for (these are hypotheses to test, not results):
* Rating the *job description* as achievement (duties instead of recognition).
* Treating the candidate's own articles as "published material about" them.
* Citing a chunk because the topic matches while the sentence does not support the specific claim.
* Rating the same evidence differently on two runs (temperature 0 reduces but does not remove this; re-run twice and compare).
* Retrieval: does the cited guidance change when the evidence changes, or is it the same chunk every time (scoping makes this likely)?

If a failure is caused by retrieval, fix chunking/query. If it is caused by the prompt, change the rubric. If the *label* was wrong, fix the label and say so.
